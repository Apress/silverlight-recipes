﻿using System.Windows.Controls;
using System.Windows.Data;

namespace Recipe4_1
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
      //In case you want to set the datacontext in code...
      //LayoutRoot.DataContext = new Company();
      //create a new Binding
      Binding CompanyNameBinding = new Binding("Name");
      //set properties on the Binding as needed
      CompanyNameBinding.Mode = BindingMode.OneWay;
      //apply the Binding to the DependencyProperty of 
      //choice on the appropriate object
      tbxCompanyName.SetBinding(TextBlock.TextProperty,
        CompanyNameBinding);


    }
  }
}
