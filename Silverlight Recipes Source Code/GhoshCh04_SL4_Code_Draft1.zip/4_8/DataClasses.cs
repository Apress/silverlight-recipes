﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;

namespace Recipe4_8
{


  public class Employee : INotifyPropertyChanged
  {
    //INotifyPropertyChanged implementation
    public event PropertyChangedEventHandler PropertyChanged;
    private void RaisePropertyChanged(PropertyChangedEventArgs e)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, e);
    }

    public Employee()
    {
    }

    private string _FirstName;
    public string FirstName
    {
      get { return _FirstName; }
      set
      {
        string OldVal = _FirstName;
        if (OldVal != value)
        {
          _FirstName = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("FirstName"));
        }
      }
    }
    private string _LastName;
    public string LastName
    {
      get { return _LastName; }
      set
      {
        string OldVal = _LastName;
        if (OldVal != value)
        {
          _LastName = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("LastName"));
        }
      }
    }
    private long _PhoneNum = 9999999999;
    public long PhoneNum
    {
      get { return _PhoneNum; }
      set
      {
          long OldVal = _PhoneNum;

        if (_PhoneNum.ToString().Trim().Length != 10)
          throw new Exception("Phone Number has to be exactly 10 digits");
     

        if (OldVal != value)
        {
          _PhoneNum = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("PhoneNum"));
        }
      }
    }
    private Address _Address;
    public Address Address
    {
      get { return _Address; }
      set
      {
        Address OldVal = _Address;
        if (OldVal != value)
        {
          _Address = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("Address"));
        }
      }
    }



    private bool _InError = default(bool);

    public bool InError
    {
      get
      {
        return _InError;
      }

      set
      {
        if (value != _InError)
        {
          _InError = value;
          if (PropertyChanged != null) 
            PropertyChanged(this, new PropertyChangedEventArgs("InError"));
        }

      }
    } 
  }

  public class Address : INotifyPropertyChanged
  {

    private static List<string> StateList = 
      new List<string>(){ "AL","AK","AS","AZ","AR","CA","CO","CT","DE","DC","FM",
        "FL","GA","GU","HI","ID","IL","IN","IA","KS","KY","LA","ME","MH","MD","MA",
        "MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","MP","OH",
        "OK","OR","PW","PA","PR","RI","SC","SD","TN","TX","UT","VT","VI","VA","WA",
        "WV","WI","WY" };

    public event PropertyChangedEventHandler PropertyChanged;
    private void RaisePropertyChanged(PropertyChangedEventArgs e)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, e);
    }

    private string _Street;
    public string Street
    {
      get { return _Street; }
      set
      {
        string OldVal = _Street;
        if (OldVal != value)
        {
          _Street = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("Street"));
        }
      }
    }
    private string _City;
    public string City
    {
      get { return _City; }
      set
      {
        string OldVal = _City;

        if (OldVal != value)
        {
          _City = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("City"));
        }
      }
    }
    private string _State;
    public string State
    {
      get { return _State; }
      set
      {
        string OldVal = _State;
        //length needs to be 2 characters
        if (StateList.Contains(value) == false)
          throw new Exception(
            "State needs to be the 2 letter abbreviation for valid US State"
            );
      
        if (OldVal != value)
        {
          _State = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("State"));
        }
      }
    }
    private string _ZipCode = null;
    public string ZipCode
    {
      get { if(_ZipCode == null)
            throw new Exception();
          else
            return _ZipCode;
      }
      set
      {
        string OldVal = _ZipCode;
        //length needs to be 5 characters
        if (value.Length != 5)
          throw new Exception("Zipcode needs to be exactly 5 digits");
        try
        {
          Convert.ToInt32(value);
        }
        catch
        {
          throw new Exception("Zipcode needs to be exactly 5 digits");
        }

        if (OldVal != value)
        {
          _ZipCode = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("ZipCode"));
        }
      }
    }
  }


}

