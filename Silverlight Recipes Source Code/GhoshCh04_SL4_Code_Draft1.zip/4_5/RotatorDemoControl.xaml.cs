﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace Recipe4_5
{
  public partial class RotatorDemoControl : UserControl, INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    public RotatorDemoControl()
    {
      InitializeComponent();

      sliderX.ValueChanged += 
        new RoutedPropertyChangedEventHandler<double>((s, e) =>
      {
        XAngle = sliderX.Value;
      });
      sliderY.ValueChanged += 
        new RoutedPropertyChangedEventHandler<double>((s, e) =>
      {
        YAngle = sliderY.Value;
      });
      sliderZ.ValueChanged +=
        new RoutedPropertyChangedEventHandler<double>((s, e) =>
      {
        ZAngle = sliderZ.Value;
      });
    } 

    private double _XAngle = default(double);

    public double XAngle
    {
      get
      {
        return _XAngle;
      }

      set
      {
        if (value != _XAngle)
        {
          _XAngle = value;
          if (PropertyChanged != null) 
            PropertyChanged(this, new PropertyChangedEventArgs("XAngle"));
        }

      }
    } 

    private double _YAngle = default(double);

    public double YAngle
    {
      get
      {
        return _YAngle;
      }

      set
      {
        if (value != _YAngle)
        {
          _YAngle = value;
          if (PropertyChanged != null) 
            PropertyChanged(this, new PropertyChangedEventArgs("YAngle"));
        }

      }
    } 

    private double _ZAngle = default(double);
    public double ZAngle
    {
      get
      {
        return _ZAngle;
      }

      set
      {
        if (value != _ZAngle)
        {
          _ZAngle = value;
          if (PropertyChanged != null) 
            PropertyChanged(this, new PropertyChangedEventArgs("ZAngle"));
        }

      }
    }    
  }

}
