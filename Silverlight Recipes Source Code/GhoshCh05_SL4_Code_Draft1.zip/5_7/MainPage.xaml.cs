﻿using System;
using System.Windows.Controls;
using Recipe5_7.AdvWorks;

namespace Recipe5_7
{
  public partial class MainPage : UserControl
  {
    AdvWorksDataServiceClient client = 
      new AdvWorksDataServiceClient();


    public MainPage()
    {
      InitializeComponent();
      GetData();
    }

    private void GetData()
    {
      client.GetProductsCompleted += 
        new EventHandler<GetProductsCompletedEventArgs>(
          delegate(object sender, GetProductsCompletedEventArgs e)
          {
            dgProducts.ItemsSource = e.Result;
          });

      client.GetProductsAsync();
    }

     
  }   
}



namespace Recipe5_7.AdvWorks
{
  public partial class Product
  {    
    public DateTime DisplayDateEnd { get { 
      return DateTime.Today + new TimeSpan(365, 0, 0, 0); } }     
  }
}


