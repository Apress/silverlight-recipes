﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Recipe5_12.AdvWorks;

namespace Recipe5_12
{
  public partial class MainPage : UserControl
  {
    internal ScrollBar HScollBar = null;
    internal ScrollBar VScollBar = null;

    public MainPage()
    {
      InitializeComponent();

      AdvWorksDataServiceClient client = new AdvWorksDataServiceClient();
      client.GetAllCategoriesCompleted +=
        new EventHandler<GetAllCategoriesCompletedEventArgs>((s, e) =>
        {
          cbxCategories.ItemsSource = e.Result;
        });
      client.GetAllCategoriesAsync();

      scrollViewer.LayoutUpdated += new EventHandler((s, e) =>
      {
        if (HScollBar == null || VScollBar == null)
        {
          List<ScrollBar> scbars =
            VisualTreeHelper.FindElementsInHostCoordinates(
          scrollViewer.TransformToVisual(
            Application.Current.RootVisual).TransformBounds(
            new Rect(0, 0, scrollViewer.ActualWidth, scrollViewer.ActualHeight)),
                scrollViewer).
                  Where((uie) => uie is ScrollBar).Cast<ScrollBar>().ToList();

          foreach (ScrollBar sc in scbars)
          {
            if (sc.Orientation == Orientation.Horizontal && HScollBar == null)
            {
              HScollBar = sc;
              sc.ValueChanged +=
            new RoutedPropertyChangedEventHandler<double>(OnHScrollValueChanged);
            }
            else if (sc.Orientation == Orientation.Vertical && VScollBar == null)
            {
              VScollBar = sc;
              sc.ValueChanged +=
            new RoutedPropertyChangedEventHandler<double>(OnVScrollValueChanged);
            }
          }
        }
      });
    } 

    void OnHScrollValueChanged(object sender, 
      RoutedPropertyChangedEventArgs<double> e)
    {

      brdrTopMenu.Margin = new Thickness
      {
        Left = brdrTopMenu.Margin.Left + (e.NewValue - e.OldValue),
        Top = brdrTopMenu.Margin.Top,
        Right = brdrTopMenu.Margin.Right,
        Bottom = brdrTopMenu.Margin.Bottom
      };

    }

    void OnVScrollValueChanged(object sender, 
      RoutedPropertyChangedEventArgs<double> e)
    {
      brdrTopMenu.Margin = new Thickness
      {
        Left = brdrTopMenu.Margin.Left,
        Top = brdrTopMenu.Margin.Top + (e.NewValue - e.OldValue),
        Right = brdrTopMenu.Margin.Right,
        Bottom = brdrTopMenu.Margin.Bottom
      };
    }

    private void btnGetProducts_Click(object sender, RoutedEventArgs e)
    {
      AdvWorksDataServiceClient client = new AdvWorksDataServiceClient();
      client.GetProductsForCategoryCompleted +=
        new EventHandler<GetProductsForCategoryCompletedEventArgs>((s, args) =>
        {
          lbxProducts.ItemsSource = args.Result;
          client.GetSubcategoryCompleted +=
            new EventHandler<GetSubcategoryCompletedEventArgs>((s1, e1) =>
          {
            (e1.UserState as Product).ProductSubCategory = e1.Result;
          });
          client.GetPhotosCompleted +=
            new EventHandler<GetPhotosCompletedEventArgs>((s2, e2) =>
          {
            (e2.UserState as Product).ProductPhoto = e2.Result;
          });
          client.GetInventoryCompleted +=
            new EventHandler<GetInventoryCompletedEventArgs>((s3, e3) =>
            {
              Product p = (e3.UserState as Product);
              p.ProductInventories = e3.Result;
              p.InventoryLevelBrush = null;
              p.InventoryLevelMessage = null;
            });
          foreach (Product prod in args.Result)
          {
            client.GetPhotosAsync(prod, prod);
            client.GetSubcategoryAsync(prod, prod);
            client.GetInventoryAsync(prod, prod);
          }

        });
      if (cbxCategories.SelectedItem != null)
        client.
          GetProductsForCategoryAsync(
          cbxCategories.SelectedItem as ProductCategory);
    }



  }
}

namespace Recipe5_12.AdvWorks
{
  public partial class ProductPhoto
  {
    private BitmapImage _LargePhotoPNG;

    public BitmapImage LargePhotoPNG
    {
      get
      {
        BitmapImage bim = new BitmapImage();
        MemoryStream ms = new MemoryStream(this.LargePhoto.Bytes);
        bim.SetSource(ms);
        ms.Close();
        return bim;
      }
      set
      {
        RaisePropertyChanged("LargePhotoPNG");
      }
    }
  }

  public partial class Product
  {
    private SolidColorBrush _InventoryLevelBrush;
    public SolidColorBrush InventoryLevelBrush
    {
      get
      {
        return (this.ProductInventories == null
          || this.ProductInventories.Count() == 0) ?
          new SolidColorBrush(Colors.Gray) :
            (this.ProductInventories[0].Quantity > this.SafetyStockLevel ?
              new SolidColorBrush(Colors.Green) :
                (this.ProductInventories[0].Quantity > this.ReorderPoint ?
                   new SolidColorBrush(Colors.Yellow) :
                    new SolidColorBrush(Colors.Red)));
      }
      set
      {
        //no actual value set here - just property change raised
        RaisePropertyChanged("InventoryLevelBrush");
      }

    }
    private string _InventoryLevelMessage;
    public string InventoryLevelMessage
    {
      get
      {
        return (this.ProductInventories == null
          || this.ProductInventories.Count() == 0) ?
          "Stock Level Unknown" :
            (this.ProductInventories[0].Quantity > this.SafetyStockLevel ?
            "In Stock" :
              (this.ProductInventories[0].Quantity > this.ReorderPoint ?
                "Low Stock" : "Reorder Now"));
      }
      set
      {
        //no actual value set here - just property change raised
        RaisePropertyChanged("InventoryLevelMessage");
      }
    }
    private ProductSubcategory _productSubCategory;
    public ProductSubcategory ProductSubCategory
    {
      get { return _productSubCategory; }
      set
      {
        _productSubCategory = value;
        RaisePropertyChanged("ProductSubCategory");
      }
    }
    private ProductCategory _productCategory;
    public ProductCategory ProductCategory
    {
      get { return _productCategory; }
      set { _productCategory = value; RaisePropertyChanged("ProductCategory"); }
    }

    private ProductPhoto _productPhoto;
    public ProductPhoto ProductPhoto
    {
      get { return _productPhoto; }
      set { _productPhoto = value; RaisePropertyChanged("ProductPhoto"); }
    }
  }
}
