﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.ComponentModel;

namespace Recipe5_14
{
  [TemplatePart(Name="elemPBar",Type=typeof(FrameworkElement))]
  public class ProgressBar : ContentControl
  {

    public static DependencyProperty CurrentValueProperty =
      DependencyProperty.Register("CurrentValue",
      typeof(double), typeof(ProgressBar),
      new PropertyMetadata(0.0,
        new PropertyChangedCallback(ProgressBar.OnCurrentValueChanged)));
    [Category("ProgressBar Values")] 
    [Description("The current value indicated by the Progress Bar")]
    public double CurrentValue
    {
      get { return (double)GetValue(CurrentValueProperty); }
      set { SetValue(CurrentValueProperty, value); }
    }

    public static DependencyProperty MaximumValueProperty =
      DependencyProperty.Register("MaximumValue",
      typeof(double), typeof(ProgressBar), new PropertyMetadata(100.0));
    [Category("ProgressBar Values")]
    [Description("The maximum value that can be measured by the Progress Bar")]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public double MaximumValue
    {
      get { return (double)GetValue(MaximumValueProperty); }
      set { SetValue(MaximumValueProperty, value); }
    }

    public static DependencyProperty MinimumValueProperty =
      DependencyProperty.Register("MinimumValue",
      typeof(double), typeof(ProgressBar), new PropertyMetadata(0.0));
    [Category("ProgressBar Values")] 
    [EditorBrowsable(EditorBrowsableState.Advanced)]    
    [Description("The minimum value that can be measured by the Progress Bar")]
    public double MinimumValue
    {
      get { return (double)GetValue(MinimumValueProperty); }
      set { SetValue(MinimumValueProperty, value); }    }

    [Category("Layout")]
    public Orientation Orientation
    {
      get { return (Orientation)GetValue(OrientationProperty); }
      set { SetValue(OrientationProperty, value); }
    }

    public static readonly DependencyProperty OrientationProperty =
        DependencyProperty.Register("Orientation",
        typeof(Orientation), typeof(ProgressBar),
        new PropertyMetadata(Orientation.Horizontal));


    
    internal FrameworkElement elemPBar { get; set; }

    public ProgressBar()
    {
      base.DefaultStyleKey = typeof(ProgressBar);
    } 

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      elemPBar = this.GetTemplateChild("elemPBar") as FrameworkElement;

      if (DesignerProperties.IsInDesignTool)
      { 
        this.Content = string.Format("Progress {0}%",this.CurrentValue);
      } 
      
    }


    internal static void OnCurrentValueChanged(DependencyObject Target,
      DependencyPropertyChangedEventArgs e)
    {
      ProgressBar pBar = Target as ProgressBar;
      if (pBar.elemPBar != null)
      {
        pBar.elemPBar.Width = (pBar.ActualWidth * (double)e.NewValue)
          / (pBar.MaximumValue - pBar.MinimumValue);
      }
      if (DesignerProperties.IsInDesignTool)
      {
        pBar.Content = string.Format("Progress {0}%", (double)e.NewValue);
      }

    }
     
  }
}
