﻿using System;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace Recipe5_14
{
  public class OrientationToTransformConverter : IValueConverter
  {
    public object Convert(object value, Type targetType,
      object parameter, System.Globalization.CultureInfo culture)
    {
      //check to see that the parameter types are conformant
      if (value == null || !(value is Orientation) || 
        targetType != typeof(Transform))
        return null; 
      if ((Orientation)value == Orientation.Horizontal)
      {
        return new RotateTransform() { Angle = 0 };
      }
      else
      {
        return new RotateTransform() { Angle = -90 };
      }

    }


    public object ConvertBack(object value, Type targetType,
      object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
