﻿using System.Windows.Controls;

namespace Recipe5_8
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();

    }

    private void PagedGrid_DataItemSelectionChanged(object sender,
      DataItemSelectionChangedEventArgs e)
    {
      if (e.CurrentItem != null)
        ProductCostInfo.Content = e.CurrentItem;
    }
  }
}
