﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interactivity;
using System.Windows.Controls.Primitives;
using System.Linq;
using System.Windows.Threading;

namespace Recipe5_15
{
  /*
  public class MediaElementSeekTriggerAction : TargetedTriggerAction<MediaElement>
  {
    bool WasPlaying = false;
    

    protected override void Invoke(object parameter)
    {
      MediaElement curTarget = TargetObject as MediaElement;
      if (curTarget != null)
      {
        if (parameter is double)
        {         

          curTarget.Position = TimeSpan.FromMilliseconds((curTarget.NaturalDuration.TimeSpan.TotalMilliseconds * (double)parameter)/100);
        }
        else if (parameter is bool)
        {
          if ((bool)parameter == true)
          {
            if (curTarget.CurrentState == MediaElementState.Playing)
            {
              WasPlaying = true;
              curTarget.Pause();
            }
          }
          else
          {
            if (WasPlaying)
              curTarget.Play();
          }
        }
      }
    }
    protected override void OnAttached()
    {
      base.OnAttached();
    }
    protected override void OnDetaching()
    {
      base.OnDetaching();
    }
    protected override void OnTargetChanged(MediaElement oldTarget, MediaElement newTarget)
    {
      base.OnTargetChanged(oldTarget, newTarget);
      
    } 
  }

  public class SliderDragTrigger : TriggerBase<Slider>
  {
    private Thumb thumb = null;
    protected override void OnAttached()
    {
      base.OnAttached();
      ;
      var ChildrenCollection = VisualTreeHelper.FindElementsInHostCoordinates(this.AssociatedObject.TransformToVisual(Application.Current.RootVisual).Transform(new Point(1, 1)), this.AssociatedObject);
      thumb = ChildrenCollection.Where((uie) => uie is Thumb).FirstOrDefault() as Thumb;

      thumb.DragStarted += new DragStartedEventHandler(thumb_DragStarted);
      thumb.DragDelta += new DragDeltaEventHandler(thumb_DragDelta);
      thumb.DragCompleted += new DragCompletedEventHandler(thumb_DragCompleted);
      
    }

    void thumb_DragStarted(object sender, DragStartedEventArgs e)
    {
      this.InvokeActions(true);
    }

    void thumb_DragCompleted(object sender, DragCompletedEventArgs e)
    {
      this.InvokeActions(false);
    }

    void thumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
      this.InvokeActions(this.AssociatedObject.Value);
    }

  
 
    protected override void OnDetaching()
    {
      base.OnDetaching();

      thumb.DragStarted += thumb_DragStarted;
      thumb.DragDelta += thumb_DragDelta;
      thumb.DragCompleted += thumb_DragCompleted;
    }
  }
  */



public class MediaElementStartPauseBehavior : Behavior<MediaElement>
{
  bool MouseDown = false;
  protected override void OnAttached()
  {
    base.OnAttached();
    //handle the appropriate mouse events on the MediaElement
    this.AssociatedObject.MouseLeftButtonDown += 
      new MouseButtonEventHandler(AssociatedObject_MouseLeftButtonDown);
    this.AssociatedObject.MouseLeftButtonUp += 
      new MouseButtonEventHandler(AssociatedObject_MouseLeftButtonUp);
    this.AssociatedObject.MouseLeave += 
      new MouseEventHandler(AssociatedObject_MouseLeave);
  }

  void AssociatedObject_MouseLeave(object sender, MouseEventArgs e)
  {
    //leaving the MediaElement - release capture is captured
    if (MouseDown)
    {
      MouseDown = false;
      this.AssociatedObject.ReleaseMouseCapture();
    }
  }

  void AssociatedObject_MouseLeftButtonUp(object sender, 
    MouseButtonEventArgs e)
  {
    //click completed
    if (MouseDown)
    {
      //if playing
      if (this.AssociatedObject.CurrentState == MediaElementState.Playing)
      {
        //pause
        this.AssociatedObject.Pause();
      }
      else
      {
        //play
        this.AssociatedObject.Play();
      }
      //release capture
      this.AssociatedObject.ReleaseMouseCapture();
      MouseDown = false;
    }
  }

  void AssociatedObject_MouseLeftButtonDown(object sender, 
    MouseButtonEventArgs e)
  {
    //capture mouse
    if (MouseDown == false)
    {
      MouseDown = true;
      this.AssociatedObject.CaptureMouse();
    }
  }

  protected override void OnDetaching()
  {
    base.OnDetaching();
    //unhook handlers
    this.AssociatedObject.MouseLeftButtonDown -= 
      AssociatedObject_MouseLeftButtonDown;
    this.AssociatedObject.MouseLeftButtonUp -= 
      AssociatedObject_MouseLeftButtonUp;
    this.AssociatedObject.MouseLeave -= 
      AssociatedObject_MouseLeave;
  }
}

  public class MediaElementPlaybackTrigger : TriggerBase<MediaElement>
  {
    DispatcherTimer playbacktimer = new DispatcherTimer(); 
    public double Interval
    {
      get { return (double)GetValue(IntervalProperty); }
      set { SetValue(IntervalProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Interval.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty IntervalProperty =
        DependencyProperty.Register("Interval", typeof(double),
        typeof(MediaElementPlaybackTrigger), new PropertyMetadata(200.0));

    

    protected override void OnAttached()
    {
      base.OnAttached();
      this.AssociatedObject.CurrentStateChanged += 
        new RoutedEventHandler(AssociatedObject_CurrentStateChanged);
      playbacktimer.Interval = TimeSpan.FromMilliseconds(Interval);
      playbacktimer.Tick += new EventHandler(playbacktimer_Tick);
    }

    void playbacktimer_Tick(object sender, EventArgs e)
    {
      this.InvokeActions(this.AssociatedObject.Position.TotalMilliseconds / 
        this.AssociatedObject.NaturalDuration.TimeSpan.TotalMilliseconds);
    }

    void AssociatedObject_CurrentStateChanged(object sender, RoutedEventArgs e)
    {
      if (this.AssociatedObject.CurrentState == MediaElementState.Playing)
      {
        playbacktimer.Start();
      }
      else
      {
        playbacktimer.Stop();
      }
    }
    protected override void OnDetaching()
    {
      base.OnDetaching();
      this.AssociatedObject.CurrentStateChanged -= 
        AssociatedObject_CurrentStateChanged;
      playbacktimer.Tick -= playbacktimer_Tick;
    }
  }

  public class SliderPlaybackProgressAction : TargetedTriggerAction<Slider>
  {
    protected override void OnAttached()
    {
      base.OnAttached();
    }
    protected override void OnDetaching()
    {
      base.OnDetaching();
    }
    protected override void OnTargetChanged(Slider oldTarget, Slider newTarget)
    {
      base.OnTargetChanged(oldTarget, newTarget);
    }
    protected override void Invoke(object parameter)
    {
      (this.Target as Slider).Value = 100 * (double)parameter;
    }
  }
  


}
