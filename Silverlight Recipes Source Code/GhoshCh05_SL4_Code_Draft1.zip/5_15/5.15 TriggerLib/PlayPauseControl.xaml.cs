﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Recipe5_15
{
  public partial class PlayPauseControl : UserControl
  {

    private MediaElement _TargetME = null;
    public MediaElement TargetME
    {
      get
      {
        return _TargetME;
      }
      set
      {
        _TargetME = value;
        
      }
    }
    public PlayPauseControl()
    {
      InitializeComponent();
      btnPlay.Click += new RoutedEventHandler(btnPlay_Click);
      btnPause.Click += new RoutedEventHandler(btnPause_Click);
    }

    void btnPause_Click(object sender, RoutedEventArgs e)
    {
      TargetME.Pause();
    }

    void btnPlay_Click(object sender, RoutedEventArgs e)
    {
      TargetME.Play();
    }
  }
}
