﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Runtime.InteropServices.Automation;

namespace Recipe8_3
{
    public class WIAEventID
    {
        public const string DeviceConnected = "{A28BBADE-64B6-11D2-A231-00C04FA31809}";
        public const string DeviceDisconnected = "{143E4E83-6497-11D2-A231-00C04FA31809}";
        public const string ItemCreated = "{4C8F4EF5-E14F-11D2-B326-00C04F68CE61}";
        public const string ItemDeleted = "{1D22A559-E14F-11D2-B326-00C04F68CE61}";
        public const string ScanImage = "{A6C5A715-8C6E-11D2-977A-0000F87A926F}";
        public const string ScanPrintImage = "{B441F425-8C6E-11D2-977A-0000F87A926F}";
        public const string ScanFaxImage = "{C00EB793-8C6E-11D2-977A-0000F87A926F}";
        public const string ScanOCRImage = "{9D095B89-37D6-4877-AFED-62A297DC6DBE}";
        public const string ScanEmailImage = "{C686DCEE-54F2-419E-9A27-2FC7F2E98F9E}";
        public const string ScanFilmImage = "{9B2B662C-6185-438C-B68B-E39EE25E71CB}";
        public const string ScanImage2 = "{FC4767C1-C8B3-48A2-9CFA-2E90CB3D3590}";
        public const string ScanImage3 = "{154E27BE-B617-4653-ACC5-0FD7BD4C65CE}";
        public const string ScanImage4 = "{A65B704A-7F3C-4447-A75D-8A26DFCA1FDF}";
    }

    public class WIACommandID
    {
        public const string Synchronize = "{9B26B7B2-ACAD-11D2-A093-00C04F72DC3C}";
        public const string TakePicture = "{AF933CAC-ACAD-11D2-A093-00C04F72DC3C}";
        public const string DeleteAllItems = "{E208C170-ACAD-11D2-A093-00C04F72DC3C}";
        public const string ChangeDocument = "{04E725B0-ACAE-11D2-A093-00C04F72DC3C}";
        public const string UnloadDocument = "{1F3B3D8E-ACAE-11D2-A093-00C04F72DC3C}";
    }

    public class WIAFormatID
    {
        public const string BMP = "{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}";
        public const string PNG = "{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}";
        public const string GIF = "{B96B3CB0-0728-11D3-9D7B-0000F81EF32E}";
        public const string JPEG = "{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}";
        public const string TIFF = "{B96B3CB1-0728-11D3-9D7B-0000F81EF32E}";
    } 

    public enum WIAPropertySubType
    {
        Unspecified, Range, List, Flag
    }

    public enum WIAPropertyType
    {
        UnsupportedPropertyType = 0,
        BooleanPropertyType = 1,
        BytePropertyType = 2,
        IntegerPropertyType = 3,
        UnsignedIntegerPropertyType = 4,
        LongPropertyType = 5,
        UnsignedLongPropertyType = 6,
        ErrorCodePropertyType = 7,
        LargeIntegerPropertyType = 8,
        UnsignedLargeIntegerPropertyType = 9,
        SinglePropertyType = 10,
        DoublePropertyType = 11,
        CurrencyPropertyType = 12,
        DatePropertyType = 13,
        FileTimePropertyType = 14,
        ClassIDPropertyType = 15,
        StringPropertyType = 16,
        ObjectPropertyType = 17,
        HandlePropertyType = 18,
        VariantPropertyType = 19,
        VectorOfBooleansPropertyType = 101,
        VectorOfBytesPropertyType = 102,
        VectorOfIntegersPropertyType = 103,
        VectorOfUnsignedIntegersPropertyType = 104,
        VectorOfLongsPropertyType = 105,
        VectorOfUnsignedLongsPropertyType = 106,
        VectorOfErrorCodesPropertyType = 107,
        VectorOfLargeIntegersPropertyType = 108,
        VectorOfUnsignedLargeIntegersPropertyType = 109,
        VectorOfSinglesPropertyType = 110,
        VectorOfDoublesPropertyType = 111,
        VectorOfCurrenciesPropertyType = 112,
        VectorOfDatesPropertyType = 113,
        VectorOfFileTimesPropertyType = 114,
        VectorOfClassIDsPropertyType = 115,
        VectorOfStringsPropertyType = 116,
        VectorOfVariantsPropertyType = 119
    }

    public enum WIADeviceType
    {
        UnspecifiedDeviceType = 0,
        ScannerDeviceType = 1,
        CameraDeviceType = 2,
        VideoDeviceType = 3
    }



    public class WIAObject : INotifyPropertyChanged
    {
      //hold the COM native object
      protected dynamic WIASource { get; private set; }
      //
      public WIAObject(dynamic Source)
      {
          WIASource = Source;
          Validate();
      } 
      //validate the COM object
      protected virtual void Validate()
      {
          if (WIASource == null) 
            throw new ArgumentNullException("Null source");
      }

      #region INotifyPropertyChanged Members

      protected void RaisePropertyChanged(string PropName)
      {
          if (PropertyChanged != null)
              PropertyChanged(this, new PropertyChangedEventArgs(PropName));
      }
      public event PropertyChangedEventHandler PropertyChanged;

      #endregion
    }

    public class WIADeviceManager : WIAObject
    {
      //raise a CLR event on handling a WIA Event
      public event EventHandler<WIAOnEventArgs> OnEvent;
      //delegate for handling DeviceManager.OnEvent
      private delegate void OnEventHandler
        (string EventID, string DeviceID, string ItemID); 
      //get all the devices 
      public IEnumerable<WIADeviceInfo> DeviceInfos
      {
        get
        {
          return (COMHelpers.COMIndexedPropertyToList(WIASource.DeviceInfos) 
            as List<dynamic>).Select(
            (DeviceInfo) => new WIADeviceInfo(DeviceInfo));
        }
      }
      //construct
      private WIADeviceManager(dynamic Source)
        : base((object)Source)
      {
        //attach handler to onEvent event
        Source.OnEvent += new OnEventHandler((eID, dID, iID) =>
        {
          //raise our own OnEvent wrapper
          if (OnEvent != null)
            OnEvent(this, new WIAOnEventArgs() 
            { EventID = eID, DeviceID = dID, ItemID = iID });
        });
      }
      //static factory method
      public static WIADeviceManager Create()
      {
        if (!AutomationFactory.IsAvailable)
          throw new InvalidOperationException
            ("COM Automation is not available");
        return new 
          WIADeviceManager(AutomationFactory.CreateObject("WIA.DeviceManager"));
      }
      //register for a WIA event
      public void RegisterEvents(string DeviceID, IEnumerable<string> Events)
      {
        Events.Any((ev) => { WIASource.RegisterEvent(ev, DeviceID); return false; });
      }
      //unregister events 
      public void UnregisterEvents(string DeviceID, IEnumerable<string> Events)
      {
        Events.Any((ev) => { WIASource.UnregisterEvent(ev, DeviceID); 
                            return false; });
      }
    }
    public class COMHelpers
    {
      public static List<dynamic> COMIndexedPropertyToList(
              dynamic IndexedPropertyCollection)
      {
        List<dynamic> RetVal = null;
        if (RetVal == null)
          RetVal = new List<dynamic>(IndexedPropertyCollection.Count);
        else
          RetVal.Clear();
        for (int i = 1; i <= IndexedPropertyCollection.Count; i++)
          RetVal.Add(IndexedPropertyCollection[i]);
        return RetVal;
      }
    }
    public class WIADeviceInfo : WIAObject
    {
      public WIADeviceInfo(dynamic Source)
        : base((object)Source)
      {
      }

      public WIADevice Connect()
      {
        WIADevice retval = new WIADevice(WIASource.Connect());
        return retval;
      }

      public WIADeviceType DeviceType
      {
        get
        {
          return (WIADeviceType)WIASource.Type;
        }
      }

      public string DeviceID
      {
        get { return (string)WIASource.DeviceID; }
      }

      public IEnumerable<WIAProperty> Properties
      {
        get { return (COMHelpers.COMIndexedPropertyToList(WIASource.Properties) 
          as List<dynamic>).Select((Prop) => new WIAProperty(Prop)); }
      }
    }
    public class WIAProperty : WIAObject
    {

        public bool IsReadOnly { get { return WIASource.IsReadOnly; } }
        public bool IsVector { get { return WIASource.IsVector; } }
        public string Name { get { return WIASource.Name; } }
        public long PropertyID { get { return WIASource.PropertyID; } }
        public dynamic DefaultValue { get { return SubType == WIAPropertySubType.Unspecified ? null : WIASource.SubTypeDefault; } }
        public dynamic Value
        {
            get
            {
                return WIASource.Value;
            }
            set
            {
                if (WIASource.Value != value)
                {
                    WIASource.Value = value;
                    RaisePropertyChanged("Value");
                }
            }
        }
        public WIAPropertyType DataType { get { return (WIAPropertyType)WIASource.Type; } }
        public WIAPropertySubType SubType { get { return (WIAPropertySubType)WIASource.SubType; } }

        public dynamic SubTypeMax { get { return SubType != WIAPropertySubType.Range ? null : WIASource.SubTypeMax; } }
        public dynamic SubTypeMin { get { return SubType != WIAPropertySubType.Range ? null : WIASource.SubTypeMin; } }
        public dynamic SubTypeStep { get { return SubType != WIAPropertySubType.Range ? null : WIASource.SubTypeStep; } }
        public WIAVector SubTypeValues { get { return WIASource.SubTypeValues; } }



        public WIAProperty(dynamic Src)
            : base((object)Src)
        {

        }
    }

    public class WIAVector : WIAObject
    {
        public WIAVector(dynamic Source)
            : base((object)Source)
        {
        }

        public byte[] BinaryData
        {
            get
            {
                byte[] Data = (byte[])WIASource.BinaryData;
                return Data;
            }
        }

        public WIAImageFile ImageFile(long Width, long Height)
        {
            return new WIAImageFile(WIASource.ImageFile(Width, Height)); 
        }
        
        
    }

    

    public class WIAOnEventArgs : EventArgs
    {
        public string EventID { get; set; }
        public string DeviceID { get; set; }
        public string ItemID { get; set; }
    }



    public class WIADevice : WIAObject
    {
 

        public WIADevice(dynamic Src)
            : base((object)Src)
        {
        }

        public WIADeviceType DeviceType
        {
            get
            {
                return (WIADeviceType)WIASource.Type;
            }
        }

        public WIAItem ExecuteCommand(string CommandID)
        {
            if (this.Commands.Where((wiacmd) => wiacmd.CommandID == CommandID).Count() > 0)
                return new WIAItem(WIASource.ExecuteCommand(CommandID));
            else
                return null;
        }

        public WIAItem GetItem(string ItemID)
        {
            return new WIAItem(WIASource.GetItem(ItemID));
        }


        public string DeviceID
        {
            get { return (string)WIASource.DeviceID; }

        }
        public WIAProperty Name
        {
            get { return Properties.Where((Prop) => Prop.Name == "Name").FirstOrDefault(); }

        }
        public WIAProperty Manufacturer
        {
            get { return Properties.Where((Prop) => Prop.Name == "Manufacturer").FirstOrDefault(); }

        }

        public IEnumerable<WIAProperty> Properties
        {
            get { return (COMHelpers.COMIndexedPropertyToList(WIASource.Properties) as List<dynamic>).Select((Prop) => new WIAProperty(Prop)); }
        }

        public IEnumerable<WIACommand> Commands
        {
            get { return (COMHelpers.COMIndexedPropertyToList(WIASource.Commands) as List<dynamic>).Select((Cmd) => new WIACommand(Cmd)); }
        }

        public IEnumerable<WIAItem> Items
        {
            get
            {
                return (COMHelpers.COMIndexedPropertyToList(WIASource.Items) as List<dynamic>).Select((Item) => new WIAItem(Item));
                
            }
        }

       

       

    }

    public class WIAImageFile : WIAObject
    {
        public WIAImageFile(dynamic Src)
            : base((object)Src)
        {
        } 

        
        public byte[] FileData
        {
            get
            {
                return  new WIAVector(WIASource.FileData).BinaryData;
            }

        }

        public byte[] ARGBData
        {
            get
            {
                return new WIAVector(WIASource.ARGBData).BinaryData;
            }

        }
        public IEnumerable<WIAProperty> Properties
        {
            get { return (COMHelpers.COMIndexedPropertyToList(WIASource.Properties) as List<dynamic>).Select((Prop) => new WIAProperty(Prop)); }
        }
        public long Height
        {
            get { return (long)WIASource.Height; }

        }
        public long Width
        {
            get { return (long)WIASource.Width; }

        }
       
        
    }
    

    public class WIAItem : WIAObject
    {
        

        public WIAItem(dynamic Src)
            : base((object)Src)
        {
        }

        public IEnumerable<WIAItem> Items
        {
            get { return (COMHelpers.COMIndexedPropertyToList(WIASource.Items) as List<dynamic>).Select((Item) => new WIAItem(Item)); }
        }

        public IEnumerable<string> Formats
        {
            get { return (COMHelpers.COMIndexedPropertyToList(WIASource.Formats) as List<dynamic>).Select((Fmt) => (string)Fmt); }
        }
        public IEnumerable<WIAProperty> Properties
        {
            get { return (COMHelpers.COMIndexedPropertyToList(WIASource.Properties) as List<dynamic>).Select((Prop) => new WIAProperty(Prop)); }
        }
        public WIAImageFile Transfer(string FormatID)
        { 
            if(Formats.Contains(FormatID))
                return new WIAImageFile(WIASource.Transfer(FormatID));
            else
                return null;
         
        }
        public WIAImageFile ThumbNail 
        {
            get
            {
                WIAProperty ThumbnailHt = Properties.Where((prop) => prop.Name == "Thumbnail Height").FirstOrDefault();
                WIAProperty ThumbnailWd = Properties.Where((prop) => prop.Name == "Thumbnail Width").FirstOrDefault();
                WIAProperty ThumbnailDataProp = Properties.Where((prop) => prop.Name == "Thumbnail Data").FirstOrDefault();
                return ThumbnailDataProp != null ? new WIAVector(ThumbnailDataProp.Value).ImageFile((long)ThumbnailWd.Value,(long)ThumbnailHt.Value) : null;
            }
        }

        

    }
    public class WIACommand : WIAObject
    {
        public WIACommand(dynamic Src)
            : base((object)Src)
        {
        }

        public string CommandID
        {
            get { return (string)WIASource.CommandID; }
        }
        public string Name
        {
            get { return (string)WIASource.Name; }
        }
        public string Description
        {
            get { return (string)WIASource.Description; }
        }

    }
    public class ItemTransferedEventArgs : EventArgs
    {
        public WIAImageFile ImageFile { get; set; }
    }
    

}