﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes; 
using System.Windows.Controls.Primitives;

namespace Recipe8_3
{
    public partial class DeviceContextMenu : UserControl
    {

        public event EventHandler ShowItems;
        public event EventHandler ShowProperties;
        public event EventHandler TakePicture;
        public event EventHandler ScanDocument;
        public event EventHandler SyncDevice;
         

        private WIADevice Device
        {
            get { return this.DataContext as WIADevice; }
            set 
            { 
                this.DataContext = value;
                 
            }
        }

        private Popup _Container;

        public Popup Container
        {
            get { return _Container; }
            set { _Container = value; }
        }

        private Point _MenuPosition;

        public Point MenuPosition
        {
            get { return _MenuPosition; }
            set { _MenuPosition = value; }
        }
        

        public static DeviceContextMenu Show(Point Position, Size AppScreenSize, WIADevice ForDevice)
        {
            DeviceContextMenu menu = new DeviceContextMenu();
            menu.Device = ForDevice;
            menu.MenuPosition = Position;
            menu.Container = new Popup();
            menu.Container.Child = menu;           
            menu.Container.HorizontalOffset = 0;
            menu.Container.VerticalOffset = 0;
            menu.Container.Height = AppScreenSize.Height;
            menu.Container.Width = AppScreenSize.Width;
            menu.Container.HorizontalAlignment = HorizontalAlignment.Stretch;
            menu.Container.VerticalAlignment = VerticalAlignment.Stretch;
            menu.Container.IsOpen = true;
            
            return menu;
            
        }
         
        private DeviceContextMenu()
        {
            InitializeComponent();
            
            this.Loaded += new RoutedEventHandler((s, e) =>
            {
                Initialize();
            });
        }
        private void Initialize()
        {
            RootCanvas.Height = Container.Height;
            RootCanvas.Width = Container.Width;
            MenuContainer.SetValue(Canvas.LeftProperty, MenuPosition.X);
            MenuContainer.SetValue(Canvas.TopProperty, MenuPosition.Y);
            RootCanvas.MouseLeftButtonDown += new MouseButtonEventHandler((s, e) =>
            {
                CloseMenu();
            });
        }

        private void CloseMenu()
        {
            this._Container.IsOpen = false;
            this._Container = null;
        }

        private void OnMenuOption_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if(btn == this.btnItems)
            {
                if(ShowItems != null)
                    ShowItems(this,EventArgs.Empty);
            }
            else if(btn == this.btnProperties)
            {
                 if(ShowProperties != null)
                    ShowProperties(this,EventArgs.Empty);
            }
            else if(btn == this.btnSync)
            {
                 if(SyncDevice != null)
                    SyncDevice(this,EventArgs.Empty);
            }
            else if(btn == this.btnScan)
            {
                 if(ScanDocument != null)
                    ScanDocument(this,EventArgs.Empty);
            }
            else if (btn == this.btnTakePic)
            {
                 if(TakePicture != null)
                    TakePicture(this,EventArgs.Empty);
            }
            CloseMenu();
        }
    }

    public class CommandEventArgs : EventArgs
    {
        public WIACommandID CommandID { get; set; }
    }
}
