﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO.IsolatedStorage;

namespace Recipe8_3
{
    public partial class App : Application
    {
        private void SaveWindowSettings()
        {
            if(IsolatedStorageSettings.ApplicationSettings.Contains("Window.Height"))
                IsolatedStorageSettings.ApplicationSettings["Window.Height"] = Application.Current.MainWindow.Height;
            else
                IsolatedStorageSettings.ApplicationSettings.Add("Window.Height", Application.Current.MainWindow.Height);

            if(IsolatedStorageSettings.ApplicationSettings.Contains("Window.Width"))
                IsolatedStorageSettings.ApplicationSettings["Window.Width"] = Application.Current.MainWindow.Width;
            else
                IsolatedStorageSettings.ApplicationSettings.Add("Window.Width", Application.Current.MainWindow.Width);

            if(IsolatedStorageSettings.ApplicationSettings.Contains("Window.Top"))
                IsolatedStorageSettings.ApplicationSettings["Window.Top"] = Application.Current.MainWindow.Top;
            else
                IsolatedStorageSettings.ApplicationSettings.Add("Window.Top", Application.Current.MainWindow.Top);

            if(IsolatedStorageSettings.ApplicationSettings.Contains("Window.Left"))
                IsolatedStorageSettings.ApplicationSettings["Window.Left"] = Application.Current.MainWindow.Left;
            else 
                IsolatedStorageSettings.ApplicationSettings.Add("Window.Left", Application.Current.MainWindow.Left);
        }

        private void LoadWindowSettings()
        {
            if(IsolatedStorageSettings.ApplicationSettings.Contains("Window.Height"))
            {
                Application.Current.MainWindow.Height = (double)IsolatedStorageSettings.ApplicationSettings["Window.Height"];
                Application.Current.MainWindow.Width = (double)IsolatedStorageSettings.ApplicationSettings["Window.Width"];
                Application.Current.MainWindow.Left = (double)IsolatedStorageSettings.ApplicationSettings["Window.Left"];
                Application.Current.MainWindow.Top = (double)IsolatedStorageSettings.ApplicationSettings["Window.Top"];
            }
        }

        public App()
        {
            this.Startup += this.Application_Startup;
            this.Exit += this.Application_Exit;
            this.UnhandledException += this.Application_UnhandledException;

            InitializeComponent();
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            if (Application.Current.IsRunningOutOfBrowser && Application.Current.HasElevatedPermissions)
            {
                LoadWindowSettings();
                this.RootVisual = new MainPage();
               
            }
            else
            {
               
                this.RootVisual = new Install();
            }
        }

        private void Application_Exit(object sender, EventArgs e)
        {
            SaveWindowSettings();
        }
        private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
        {
            // If the app is running outside of the debugger then report the exception using
            // the browser's exception mechanism. On IE this will display it a yellow alert 
            // icon in the status bar and Firefox will display a script error.
            if (!System.Diagnostics.Debugger.IsAttached)
            {

                // NOTE: This will allow the application to continue running after an exception has been thrown
                // but not handled. 
                // For production applications this error handling should be replaced with something that will 
                // report the error to the website and stop the application.
                e.Handled = true;
                Deployment.Current.Dispatcher.BeginInvoke(delegate { ReportErrorToDOM(e); });
            }
        }
        private void ReportErrorToDOM(ApplicationUnhandledExceptionEventArgs e)
        {
            try
            {
                string errorMsg = e.ExceptionObject.Message + e.ExceptionObject.StackTrace;
                errorMsg = errorMsg.Replace('"', '\'').Replace("\r\n", @"\n");

                System.Windows.Browser.HtmlPage.Window.Eval("throw new Error(\"Unhandled Error in Silverlight 2 Application " + errorMsg + "\");");
            }
            catch (Exception)
            {
            }
        }
    }
}
