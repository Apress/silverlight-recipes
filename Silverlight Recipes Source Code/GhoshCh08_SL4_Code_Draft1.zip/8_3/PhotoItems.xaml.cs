﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes; 
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.IO;
using System.Windows.Media.Imaging;

namespace Recipe8_3
{
    public partial class PhotoItems : UserControl
    {
        public WIADevice Device { get; set; }
        //public ObservableCollection<WIAImageFile> Images = null;
        public PhotoItems()
        {
            InitializeComponent();
            
            this.Loaded += new RoutedEventHandler(PhotoItems_Loaded);
        }

        void PhotoItems_Loaded(object sender, RoutedEventArgs args)
        {

            PhotoPager.Source = new PagedCollectionView(
              Device.Items.Where((itm) => itm.Formats.Contains(WIAFormatID.JPEG))) 
              { PageSize = 1 }; 

            ShowPhoto(); 
            PhotoPager.PageIndexChanged += new EventHandler<EventArgs>((s, e) =>
            {
                ShowPhoto();
            });         
            return;
        } 

        private void ShowPhoto()
        {
            try
            {
                WIAImageFile img = ((PhotoPager.Source as PagedCollectionView).
                  CurrentItem as WIAItem).Transfer(WIAFormatID.JPEG);
                if (img == null) Photo.DataContext = null;
                else
                    Photo.DataContext = img.FileData;
            }
            catch (Exception Ex)
            {
                Photo.DataContext = null;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
          //get the current WIAItem
          WIAItem itm = ((PhotoPager.Source as PagedCollectionView).
            CurrentItem as WIAItem);
          //get the raw data
          byte[] FileData = Photo.DataContext as byte[];
          //get the filename from the Item Properties collection
          string filename = itm.Properties.ToList().Where((wiaprop) =>
            wiaprop.Name == "Item Name").Select((wiaprop) =>
              (string)wiaprop.Value).FirstOrDefault();
          //create a file
          FileStream fs = File.Create(
            System.IO.Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), 
            filename + ".jpeg"));
          //write
          fs.Write(FileData, 0, FileData.Length);
          //close file
          fs.Close();     
        }         
}

    public class WIAImageFileToBitmapConverter : IValueConverter
    {

        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null) return null;
            if (!(value is byte[]) || targetType != typeof(ImageSource)) return null;

            BitmapImage bi = new BitmapImage();
            bi.SetSource(new MemoryStream((byte[])value));
            return bi;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
