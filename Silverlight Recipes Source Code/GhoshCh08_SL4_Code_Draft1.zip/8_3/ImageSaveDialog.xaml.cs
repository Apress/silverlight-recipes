﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Recipe8_3
{
    public partial class ImageSaveDialog : UserControl
    {

        public event EventHandler<StringEventArgs> FolderSelected;
        public ImageSaveDialog()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(ImageSaveDialog_Loaded);
 
        }

        void ImageSaveDialog_Loaded(object sender, RoutedEventArgs e)
        {          
            tvFolders.ItemsSource = new ObservableCollection<DirectoryInfoExt>(Directory.EnumerateDirectories(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)).Select((sz)=>new DirectoryInfoExt(new DirectoryInfo(sz))));
        }

        private void btnNewFolder_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (sender as Button);

            if ((btn.Content as string).Equals("New Folder"))
            {
                tbxFolderName.Visibility = Visibility.Visible;
                btn.Content = "Apply";
            }
            else
            {
                try
                {
                    if (tbxFolderName.Text != null && tbxFolderName.Text != string.Empty && tvFolders.SelectedValue != null)
                    {
                        DirectoryInfoExt dix = tvFolders.SelectedValue as DirectoryInfoExt;
                        dix.DI.CreateSubdirectory(tbxFolderName.Text);
                        dix.RaisePropertyChanged("SubFolders");
                    }
                }
                catch (Exception Ex)
                { }
                btn.Content = "New Folder";
                tbxFolderName.Text = string.Empty;
                tbxFolderName.Visibility = Visibility.Collapsed;
            }
             
        }

        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
             if(FolderSelected != null)
                 FolderSelected(this,new StringEventArgs() { Value = (tvFolders.SelectedValue as DirectoryInfoExt).DI.FullName });
        }

        
    }

    public class StringEventArgs : EventArgs
    {
        public string Value { get; set; }

    }
    public class DirectoryInfoExt : INotifyPropertyChanged
    {
        public DirectoryInfo DI { get; set; }
        public DirectoryInfoExt(DirectoryInfo di)
        {
            DI = di;
            
        }


        public void RaisePropertyChanged(string PropertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
            }
        }
         
        public string Name
        {
            get
            {
                return DI.Name;
            }

            set
            {
              

            }
        }

        
        public ObservableCollection<DirectoryInfoExt> SubFolders
        {
            get
            {
                ObservableCollection<DirectoryInfoExt> RetVal = null;
                try
                {
                    RetVal = new ObservableCollection<DirectoryInfoExt>(DI.EnumerateDirectories().Select((d) => new DirectoryInfoExt(d)));
                }
                catch (Exception Ex)
                {
                    
                }

                return RetVal;
            }

            set
            {
               

            }
        }

         

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}
