﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Recipe8_3
{
    public partial class DeviceConnectDisconnectNotification : UserControl
    {

        public bool Connected { get; set; }
        public NotificationWindow NotificationParent { get; set; }
        public DeviceConnectDisconnectNotification()
        {
            InitializeComponent();

            
            this.Loaded += new RoutedEventHandler(DeviceConnectDisconnectNotification_Loaded);
        }

        void DeviceConnectDisconnectNotification_Loaded(object sender, RoutedEventArgs e)
        {
            tblkConnectStatus.Text = Connected ? "Connected: " : "Disconnected: ";
            tblkDevice.Text = (DataContext as WIADevice).Name.Value as string;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            NotificationParent.Close();
        }
    }
}
