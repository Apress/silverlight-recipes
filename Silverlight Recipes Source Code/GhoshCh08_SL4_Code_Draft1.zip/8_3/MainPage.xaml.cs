﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace Recipe8_3
{
     
    public partial class MainPage : UserControl
    {
      //event handler delegate to handle the WIADeviceManager.OnEvent event
        public delegate void WIADeviceManageOnEventHandler(string EventID, 
          string DeviceID, string ItemID);
      //WIADeviceManager singleton
        WIADeviceManager wiaDeviceManager = null;
      //the collection of all connected devices
        ObservableCollection<WIADevice> WIADevicesColl = 
          new ObservableCollection<WIADevice>();

        public MainPage()
        {
            InitializeComponent();
          //create the DeviceManager
            wiaDeviceManager = WIADeviceManager.Create();
          //register for connection and disconnection events for all devices 
          //that WIA might recognize
            wiaDeviceManager.RegisterEvents("*",
              new string[]{WIAEventID.DeviceConnected,WIAEventID.DeviceDisconnected});
          //attach event handler for OnEvent
            wiaDeviceManager.OnEvent += 
              new EventHandler<WIAOnEventArgs>(wiaDeviceManager_OnEvent);
          //get and connect all the devices
            WIADevicesColl = new ObservableCollection<WIADevice>(
              wiaDeviceManager.DeviceInfos.Select((di) => di.Connect()));
           //set the device list 
            lbxDevices.ItemsSource = WIADevicesColl;
        }

        void wiaDeviceManager_OnEvent(object sender, WIAOnEventArgs e)
        {
          //if a device just connected
            if (e.EventID == WIAEventID.DeviceConnected )
            { 
              //connect it
                WIADevice wiaDevice = wiaDeviceManager.DeviceInfos.
                  Where((di) => di.DeviceID == e.DeviceID).
                  Select((di) => di.Connect()).First();
              //add to the bound collection
                WIADevicesColl.Add(wiaDevice);
              //if minimized - show notification
                if (Application.Current.MainWindow.WindowState == 
                  WindowState.Minimized)
                {
                    DeviceConnectDisconnectNotification notfcontent = 
                      new DeviceConnectDisconnectNotification() 
                      { DataContext = wiaDevice, Connected = true};
                    NotificationWindow notfWindow = new NotificationWindow() 
                    { Height = 60, Width = 400, Content = notfcontent };
                    notfcontent.NotificationParent = notfWindow;
                    notfWindow.Show(30000);
                    
                }
            }
              //if device disconnected
            else if (e.EventID == WIAEventID.DeviceDisconnected && 
              WIADevicesColl.Where((wiaDeviceInfo)=>wiaDeviceInfo.DeviceID 
                == e.DeviceID).Count() > 0)
            {
              //remove it
                WIADevice wiaDevice = WIADevicesColl.
                  Where((de) => de.DeviceID == e.DeviceID).First();                 
                WIADevicesColl.Remove(wiaDevice);
            }
        }

        private void lbxDevices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          //get the selected device
          WIADevice Device = lbxDevices.SelectedValue as WIADevice;
          //display the content on the right pane
          DisplayCameraItems(Device);
        }

        private void DisplayCameraItems( WIADevice CameraDevice)
        {
          //create a new instance of the PhotoItems user control
          //and bind appropriate data
            cntctlDataPane.Content = new PhotoItems() 
            { Device = CameraDevice, 
              HorizontalAlignment = HorizontalAlignment.Stretch, 
              VerticalAlignment = VerticalAlignment.Stretch };
        } 
      
    }

    public class DeviceTypeToDeviceImageConverter : IValueConverter
    {

        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            int type = (int)value;
            Uri uri = null;
            switch (type)
            {
                case 0:
                default:
                    uri = new Uri("/Recipe8_3;component/Images/GenericDevice.png",UriKind.Relative);
                    break;
                case 1:
                    uri = new Uri("/Recipe8_3;component/Images/Scanner.png", UriKind.Relative);
                    break;
                case 2:
                    uri = new Uri("/Recipe8_3;component/Images/Camera.png", UriKind.Relative);
                    break;
                case 3:
                    uri = new Uri("/Recipe8_3;component/Images/VideoCamera.png", UriKind.Relative);
                    break;
                   
            }
            return new BitmapImage(uri);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    
}
