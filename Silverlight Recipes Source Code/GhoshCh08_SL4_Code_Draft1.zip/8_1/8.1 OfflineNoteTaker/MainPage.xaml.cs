﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.Serialization.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Recipe8_1.NoteManager;

namespace Recipe8_1
{
  public partial class MainPage : UserControl, INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;
    //initialize to a blank note
    private Note _CurrentNote = new Note()
    {
      NoteID = Guid.NewGuid().ToString(),
      LastModified = DateTime.Now
    };

    //Tracks the currently selected/displayed note
    public Note CurrentNote
    {
      get { return _CurrentNote; }
      set
      {
        if (value != _CurrentNote)
        {
          _CurrentNote = value;
          if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs("CurrentNote"));
        }
      }
    }

    private ObservableCollection<TreeNodeData> _NotesByDate =
      default(ObservableCollection<TreeNodeData>);
    //Collection of TreeNodeData that binds to the TreeView to display saved notes
    public ObservableCollection<TreeNodeData> NotesByDate
    {
      get
      {
        //initialize to a blank collection
        if (_NotesByDate == null)
          _NotesByDate = new ObservableCollection<TreeNodeData>();
        return _NotesByDate;
      }
      set
      {
        if (value != _NotesByDate)
        {
          _NotesByDate = value;
          if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs("NotesByDate"));
        }
      }
    }

    //Indicates if the app is running offline - used to bind to XAML
    public bool Installed
    {
      get
      {
        return Application.Current.InstallState == InstallState.Installed;
      }
    }
    //Indicates if network connectivity is available - used to bind to XAML
    public bool NetworkOn
    {
      get
      {
        return NetworkInterface.GetIsNetworkAvailable();
      }
    }

    public MainPage()
    {
      InitializeComponent();
      //Refresh notes treeview
      RefreshNotesView();
      //listen for network connection/disconnection events
      NetworkChange.NetworkAddressChanged +=
        new NetworkAddressChangedEventHandler((s, a) =>
        {
          //update XAML bound property
          if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs("NetworkOn"));
          //refersh the treeview to display remote/local notes appropriately
          RefreshNotesView();
        });
      //handle selection change in the notes treeview
      NotesTree.SelectedItemChanged +=
        new RoutedPropertyChangedEventHandler<object>((s, a) =>
      {
        if (a.NewValue is Note)
        {
          //set the CurrentNote property to the currently selected note
          CurrentNote = a.NewValue as Note;
        }
      });
    }

    //take the application offline
    private void btnInstall_Click(object sender, RoutedEventArgs e)
    {
      Application.Current.Install();
    }
    private void RefreshNotesView()
    {
      //clear current bound collection
      NotesByDate.Clear();
      //reinitialize the CurrentNote
      CurrentNote = new Note()
      {
        NoteID = Guid.NewGuid().ToString(),
        LastModified = DateTime.Now
      };
      //if we have network connectivity
      if (NetworkOn)
      {
        //use the WCF proxy
        NoteManagerClient client = new NoteManagerClient();
        //handle getting all the dates asynchronously
        client.GetDatesCompleted +=
          new EventHandler<GetDatesCompletedEventArgs>((sender, args) =>
        {

          foreach (DateTime dt in args.Result)
          {
            //create another instance of the WCF proxy
            NoteManagerClient client1 = new NoteManagerClient();
            //handle getting the notes for a date asynchronously
            client1.GetNotesForDateCompleted +=
              new EventHandler<GetNotesForDateCompletedEventArgs>((s, a) =>
            {


              //create a node for the date and add the notes to it
              NotesByDate.Add(
                new TreeNodeData()
                {
                  Date = (DateTime)a.UserState,
                  Notes = new ObservableCollection<Note>(a.Result)
                });
            });
            //get all the notes on the server for a specific date
            //pass in the date as user state
            client1.GetNotesForDateAsync(dt, dt);
          }
        });
        //get all the dates for which we have notes on the server
        client.GetDatesAsync();
      }
      else
      {
        //create a client for local note management
        LocalNoteManagerClient client = new LocalNoteManagerClient();
        //Get all the dates
        List<DateTime> dates = client.GetDates();
        foreach (DateTime dt in dates)
        {
          //get the notes for that date
          ObservableCollection<Note> notesForDate = client.GetNotesForDate(dt);
          //add to the treeview          
          NotesByDate.Add(
            new TreeNodeData()
            {
              Date = dt,
              Notes = notesForDate
            });
        }
      }
    }

    //handle the Save button
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (NetworkOn)
      {
        //use the WCF proxy
        NoteManagerClient client = new NoteManagerClient();
        client.AddNoteCompleted +=
          new EventHandler<AsyncCompletedEventArgs>((s, a) =>
        {
          //refresh the treeview
          RefreshNotesView();
        });
        //add the new/updated note to the server
        client.AddNoteAsync(CurrentNote);
      }
      else
      {
        //use the local note manager
        LocalNoteManagerClient client = new LocalNoteManagerClient();
        //add the note
        client.AddNote(CurrentNote);
        //refresh the tree view
        RefreshNotesView();
      }
    }

    //handle the New Button
    private void btnNew_Click(object sender, RoutedEventArgs e)
    {
      //reinitialize the CurrentNote
      CurrentNote = new Note()
      {
        NoteID = Guid.NewGuid().ToString(),
        LastModified = DateTime.Now
      };
    }

    //handle Remove button
    private void btnRemove_Click(object sender, RoutedEventArgs e)
    {
      //a valid existing note has to be selected
      if (CurrentNote == null ||
        NotesByDate.SelectMany((tnd) => tnd.Notes).
        Where((nt) => nt == CurrentNote).Count() > 0)
        return;

      if (NetworkOn)
      {
        //use the WCF proxy
        NoteManagerClient remoteClient = new NoteManagerClient();
        remoteClient.RemoveNoteCompleted +=
          new EventHandler<AsyncCompletedEventArgs>((s, a) =>
          {
            //refresh tree view
            RefreshNotesView();
          });
        //remove the note
        remoteClient.RemoveNoteAsync(CurrentNote.LastModified, CurrentNote.NoteID);
      }
      else
      {
        //use the local client
        LocalNoteManagerClient localClient = new LocalNoteManagerClient();
        //remove note
        localClient.RemoveNote(CurrentNote.LastModified, CurrentNote.NoteID);
        //refresh tree view
        RefreshNotesView();
      }
    }

    //handle Synchronize button
    private void btnSynchronize_Click(object sender, RoutedEventArgs e)
    {
      SynchronizeOfflineStore();
    }

    private void SynchronizeOfflineStore()
    {
      LocalNoteManagerClient localClient = new LocalNoteManagerClient();
      //Notes that are on the server with LastModifiedDate <= LastSynchronizedDate
      //but are missing on the client, must have been deleted on the client
      List<Note> NotesDeletedOnClient =
        NotesByDate.SelectMany((tnd) => tnd.Notes).Distinct().
                  Where((nt) => nt.LastSynchronized >= nt.LastModified).
                  Except(localClient.GetDates().
             SelectMany((dt) => localClient.GetNotesForDate(dt)).
             Distinct()).ToList();
      //remove the deleted notes from the server
      foreach (Note nt in NotesDeletedOnClient)
      {
        NoteManagerClient remoteClient = new NoteManagerClient();
        remoteClient.RemoveNoteAsync(nt.LastModified, nt.NoteID);
      }
      //Notes that are on the client with LastModifiedDate <= LastSynchronizedDate
      //but are missing on the server, must have been deleted on the server
      List<Note> NotesDeletedOnServer =
        localClient.GetDates().
             SelectMany((dt) => localClient.GetNotesForDate(dt)).Distinct().
             Where((nt) => nt.LastSynchronized >= nt.LastModified).Except(
        NotesByDate.SelectMany((tnd) => tnd.Notes).Distinct()).ToList();
      //remove the deleted notes from the client
      foreach (Note nt in NotesDeletedOnServer)
        localClient.RemoveNote(nt.LastModified, nt.NoteID);
      //get all the notes on the server that have not been synchronized with the 
      //client. Since we are online, the notes represented in NotesByDate 
      //constitutes the server state
      List<Note> NotesOutOfSyncOnServer =
            NotesByDate.SelectMany((tnd) => tnd.Notes).Distinct().
                  Where((nt) => nt.LastSynchronized == null ||
                    nt.LastSynchronized < nt.LastModified).ToList();
      //add the server side notes to the client
      foreach (Note nt in NotesOutOfSyncOnServer)
      {
        //set appropriate timestamps
        nt.LastSynchronized = DateTime.Now;
        nt.LastModified = nt.LastSynchronized.Value;
        localClient.AddNote(nt);
      }
      //get all the notes on the client that have not been synchronized with the 
      //server.  
      List<Note> NotesOutOfSyncOnClient =
             localClient.GetDates().
             SelectMany((dt) => localClient.GetNotesForDate(dt)).Distinct().
               Where((nt) => nt.LastSynchronized == null ||
                 nt.LastSynchronized < nt.LastModified).ToList();

      //add the client side notes to the server
      foreach (Note nt in NotesOutOfSyncOnClient)
      {
        NoteManagerClient remoteClient = new NoteManagerClient();
        //timestamps
        nt.LastSynchronized = DateTime.Now;
        nt.LastModified = nt.LastSynchronized.Value;
        remoteClient.AddNoteAsync(nt);
      }
      //refresh
      RefreshNotesView();
    }
  }

  //Represents a top level node (Date) in the tree view
  //with children nodes (Note)
  public class TreeNodeData : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;
    private DateTime _Date = default(DateTime);
    public DateTime Date
    {
      get
      {
        return _Date;
      }
      set
      {
        if (value != _Date)
        {
          _Date = value;
          if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs("Date"));
        }
      }
    }

    private ObservableCollection<Note> _Notes =
      default(ObservableCollection<Note>);
    public ObservableCollection<Note> Notes
    {
      get
      {
        return _Notes;
      }
      set
      {
        if (value != _Notes)
        {
          _Notes = value;
          if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs("Notes"));
        }
      }
    }
  }

  //Value Converter from boolean to Visiblity
  //Default logic converts boolean true to Visibility.Visible and vice versa
  //Pass ConverterParameter = 'reverse' to reverse conversion logic
  public class BoolToVisibilityConverter : IValueConverter
  {
    public object Convert(object value, Type targetType,
      object parameter, System.Globalization.CultureInfo culture)
    {
      //check to see that the parameter types are conformant
      if (!(value is bool) || targetType != typeof(Visibility))
        return null;
      if (parameter != null &&
        parameter is string &&
        (parameter as string).ToLower().Equals("reverse"))
        return (bool)value == false ? Visibility.Visible : Visibility.Collapsed;
      else
        return (bool)value == true ? Visibility.Visible : Visibility.Collapsed;

    }


    public object ConvertBack(object value, Type targetType,
      object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }

  //Manages notes on the local client using Isolated Storage as the backing store
  public class LocalNoteManagerClient
  {
    //gets all the dates
    public List<DateTime> GetDates()
    {
      IsolatedStorageFile AppStore =
        IsolatedStorageFile.GetUserStoreForApplication();
      //get all the existing folders - each folder represents a date 
      //for which notes exist
      string[] val = AppStore.GetDirectoryNames();
      return AppStore.GetDirectoryNames().
        Select((sz) => DateTime.Parse(sz.Replace("_", "/"))).ToList();
    }
    //gets all the notes stored in local storage for a specific date
    public ObservableCollection<Note> GetNotesForDate(DateTime ForDate)
    {
      ObservableCollection<Note> RetVal = new ObservableCollection<Note>();
      IsolatedStorageFile AppStore =
        IsolatedStorageFile.GetUserStoreForApplication();
      //get the folder corresponding to this date
      string DirPath = ForDate.ToShortDateString().Replace("/", "_");
      //if folder exists
      if (AppStore.DirectoryExists(DirPath))
      {
        //get all the files
        string[] FileNames = AppStore.
          GetFileNames(System.IO.Path.Combine(DirPath, "*.note"));
        foreach (string FileName in FileNames)
        {
          //open a file
          IsolatedStorageFileStream fs = AppStore.
            OpenFile(System.IO.Path.Combine(DirPath, FileName), FileMode.Open);
          //deserialize
          DataContractJsonSerializer serNote =
            new DataContractJsonSerializer(typeof(Note));
          //add to returned collection
          RetVal.Add(serNote.ReadObject(fs) as Note);
          //close file
          fs.Close();
        }
      }
      //return collection
      return RetVal;
    }
    //adds a note to local storage
    public void AddNote(Note note)
    {
      IsolatedStorageFile AppStore =
        IsolatedStorageFile.GetUserStoreForApplication();
      string DirPath = note.LastModified.ToShortDateString().Replace("/", "_");
      //if a directory for the note date does not exist - create one
      if (AppStore.DirectoryExists(DirPath) == false)
        AppStore.CreateDirectory(DirPath);
      string FilePath = string.Format("{0}\\{1}",
        DirPath, note.NoteID + ".note");
      //create file, serialize and store
      IsolatedStorageFileStream fs = AppStore.
        OpenFile(FilePath, FileMode.Create);
      DataContractJsonSerializer serNote =
        new DataContractJsonSerializer(typeof(Note));
      serNote.WriteObject(fs, note);
      fs.Close();
    }
    //removes a note from local storage
    public void RemoveNote(DateTime ForDate, string NoteID)
    {
      IsolatedStorageFile AppStore =
        IsolatedStorageFile.GetUserStoreForApplication();
      string FilePath = string.Format("{0}\\{1}",
          ForDate.ToShortDateString().Replace("/", "_"), NoteID + ".note");

      if (AppStore.FileExists(FilePath))
        AppStore.DeleteFile(FilePath);
    }
  }
}

//extend the note type in the WCF proxy, to incorporate equality comparison 
//semantics
namespace Recipe8_1.NoteManager
{
  public partial class Note
  {
    public override bool Equals(object obj)
    {
      return (obj is Note && (obj as Note).NoteID.Equals(this.NoteID));
    }
    public override int GetHashCode()
    {
      return this.NoteID.GetHashCode();
    }
  }
}
