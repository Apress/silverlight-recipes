﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using System.Web;
using System.IO; 
using System.Runtime.Serialization.Json;

namespace Recipe8_2
{
  [AspNetCompatibilityRequirements
    (RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
  public class NoteManager : INoteManager
  {

    //get all the dates - each existing foler corresponds to a date
    public List<DateTime> GetDates()
    {
      string NotePath = HttpContext.Current.Server.MapPath("NoteData");
      return Directory.GetDirectories(NotePath).
        Select((sz) => DateTime.Parse(
          sz.Split(new string[] { "\\" },
          StringSplitOptions.None).Last().Replace("_", "/"))).ToList();
    }
    //get the notes for a specific date
    //enumerate the files in the corresponding folder, deserialize and return
    public List<Note> GetNotesForDate(DateTime ForDate)
    {
      string NotePath = string.Format("{0}\\{1}",
        HttpContext.Current.Server.MapPath("NoteData"),
        ForDate.ToShortDateString().Replace("/", "_"));
      if (Directory.Exists(NotePath) == false)
        return null;
      else
      {
        List<Note> RetVal = new List<Note>();
        string[] NoteFiles = Directory.GetFiles(NotePath, "*.note");
        foreach (string NoteFile in NoteFiles)
        {
          using (FileStream fs =
            new FileStream(NoteFile, FileMode.Open, FileAccess.Read))
          {
            DataContractJsonSerializer noteSer =
              new DataContractJsonSerializer(typeof(Note));
            RetVal.Add(noteSer.ReadObject(fs) as Note);
            fs.Close();
          }
        }
        return RetVal;
      }

    }
    //add a note - serialize and store in a file in the corresponding date folder
    public void AddNote(Note note)
    {
      string NotePath = string.Format("{0}\\{1}",
        HttpContext.Current.Server.MapPath("NoteData"),
        note.LastModified.ToShortDateString().Replace("/", "_"));

      if (Directory.Exists(NotePath) == false)
        Directory.CreateDirectory(NotePath);

      using (FileStream fs = new FileStream
        (
          string.Format("{0}\\{1}",
          NotePath, note.NoteID + ".note"),
          FileMode.Create,
          FileAccess.ReadWrite)
        )
      {
        DataContractJsonSerializer noteSer = 
          new DataContractJsonSerializer(typeof(Note)); 
        noteSer.WriteObject(fs, note);
        fs.Close();
      }
    }
    //remove note - remove the corresponding file
    public void RemoveNote(DateTime ForDate, string NoteID)
    {

      string FilePath = string.Format("{0}\\{1}\\{2}",
        HttpContext.Current.Server.MapPath("NoteData"),
        ForDate.ToShortDateString().Replace("/", "_"),
        NoteID + ".note");

      if (File.Exists(FilePath))
        File.Delete(FilePath);
     
    }
 
    
 
  }
}
