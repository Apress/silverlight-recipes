﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace Recipe8_2
{  
  [ServiceContract]
  public interface INoteManager
  {
    //Get all the dates for which we have notes stored
    [OperationContract]
    List<DateTime> GetDates();

    //Get all the notes for a specific date
    [OperationContract]
    List<Note> GetNotesForDate(DateTime ForDate);

    //Add a note to the note store
    [OperationContract]
    void AddNote(Note note);

    //Remove a note from the note store
    [OperationContract]
    void RemoveNote(DateTime ForDate, string NoteID); 
  }

  [DataContract]
  public class Note
  {
    //Unique ID for the note
    [DataMember]
    public string NoteID { get; set; }
    //When was the note created or last modified ?
    [DataMember]
    public DateTime LastModified { get; set; }
    //When was the note last synchronized ?
    [DataMember]
    public DateTime? LastSynchronized { get; set; }
    //Note title
    [DataMember]
    public string Title { get; set; }
    //Note body
    [DataMember]
    public string Body { get; set; }    
  }
}
