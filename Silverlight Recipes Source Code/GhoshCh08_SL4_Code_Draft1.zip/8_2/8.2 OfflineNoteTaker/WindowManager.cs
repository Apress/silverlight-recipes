﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Recipe8_2
{
  public static class WindowManager
  {
    private static FrameworkElement ShellRoot;
    //a rect defined on the window determining the hit target that
    //we will use to determine if a mouse drag causes the window to move
    private static Rect MoveHandleRect = default(Rect);
    //the width from the edges of the window determining the hit target 
    //we will use to determine if a mouse drag causes a resize
    private static double ResizeHandleWidth = 8;
    //store the old cursor to revert back when necessary
    static Cursor OldCursor = null;
    //current action on the window
    static Action CurrentAction = Action.None; 

    //enumeration defining the current action on the window
    private enum Action
    {
      Moving, Resizing, None
    } 
    //register the FrameworkElement whose mouse movements
    //will determine the various window move and resize logic
    public static void RegisterShell(FrameworkElement shellRoot, 
      double resizeHandleWidth, Rect moveHandleRect, 
      Button btnMinimize, Button btnMaximize, Button btnClose)
    {
      ShellRoot = shellRoot;
      ResizeHandleWidth = resizeHandleWidth;
      MoveHandleRect = moveHandleRect;
      OldCursor = ShellRoot.Cursor;
      //handle the various mouse events
      ShellRoot.MouseEnter += new MouseEventHandler(ShellRoot_MouseEnter);
      ShellRoot.MouseLeave += new MouseEventHandler(ShellRoot_MouseLeave);
      ShellRoot.MouseMove += new MouseEventHandler(ShellRoot_MouseMove);
      ShellRoot.MouseLeftButtonDown += 
        new MouseButtonEventHandler(ShellRoot_MouseLeftButtonDown);
      ShellRoot.MouseLeftButtonUp += 
        new MouseButtonEventHandler(ShellRoot_MouseLeftButtonUp);
      //handle the control button events
      btnClose.Click += new RoutedEventHandler(btnClose_Click);
      btnMaximize.Click += new RoutedEventHandler(btnMaximize_Click);
      btnMinimize.Click += new RoutedEventHandler(btnMinimize_Click); 
    }

    private static void btnMinimize_Click(object sender, 
      System.Windows.RoutedEventArgs e)
    {
      Application.Current.MainWindow.WindowState = WindowState.Minimized;
    }

    private static void btnMaximize_Click(object sender, 
      System.Windows.RoutedEventArgs e)
    {
      Application.Current.MainWindow.WindowState =
        Application.Current.MainWindow.WindowState == WindowState.Maximized ?
        WindowState.Normal : WindowState.Maximized;
    }

    private static void btnClose_Click(object sender, 
      System.Windows.RoutedEventArgs e)
    {
      Application.Current.MainWindow.Close();
    }

    private static void ShellRoot_MouseEnter(object sender, MouseEventArgs e)
    {
      SetMouseCursor(e);
    }
    static void ShellRoot_MouseLeftButtonDown(object sender, 
      MouseButtonEventArgs e)
    {
      CurrentAction = (GetCurrentResizeEdge(e) != default(WindowResizeEdge)) ? 
        Action.Resizing : (IsMouseOnMoveZone(e) ? Action.Moving : Action.None);

    }
    static void ShellRoot_MouseLeftButtonUp(object sender, 
      MouseButtonEventArgs e)
    {
      CurrentAction = Action.None;
    }

    static void ShellRoot_MouseMove(object sender, MouseEventArgs e)
    {
      if (CurrentAction == Action.Resizing)
      {
        Application.Current.MainWindow.DragResize(GetCurrentResizeEdge(e)); 
      }
      else if (CurrentAction == Action.Moving)
      {
        Application.Current.MainWindow.DragMove();
      }
      else
        SetMouseCursor(e);
    } 

    static void ShellRoot_MouseLeave(object sender, MouseEventArgs e)
    {
      if (CurrentAction != Action.None)
      {
        CurrentAction = Action.None;
        SetMouseCursor(e);
      }
    }

    private static void SetMouseCursor(MouseEventArgs e)
    {
      WindowResizeEdge ResizeZone = GetCurrentResizeEdge(e);

      if (ResizeZone != default(WindowResizeEdge) && OldCursor == default(Cursor))
        OldCursor = ShellRoot.Cursor;

      switch (ResizeZone)
      {
        case WindowResizeEdge.Top:
        case WindowResizeEdge.Bottom:
          ShellRoot.Cursor = Cursors.SizeNS;
          break;
        case WindowResizeEdge.Left:
        case WindowResizeEdge.Right:
          ShellRoot.Cursor = Cursors.SizeWE;
          break;
        case WindowResizeEdge.TopLeft:
        case WindowResizeEdge.BottomRight:
          ShellRoot.Cursor = Cursors.SizeNWSE;
          break;
        case WindowResizeEdge.TopRight:
        case WindowResizeEdge.BottomLeft:
          ShellRoot.Cursor = Cursors.SizeNESW;
          break;
        default:
          ShellRoot.Cursor = OldCursor;
          OldCursor = default(Cursor);
          break;
      }
    }

    private static bool IsMouseOnMoveZone(MouseEventArgs e)
    {
      return Application.Current.MainWindow.WindowState ==
        WindowState.Maximized ? false :
        MoveHandleRect.Contains(e.GetPosition(ShellRoot));
    }

    private static WindowResizeEdge GetCurrentResizeEdge(MouseEventArgs e)
    {
      WindowResizeEdge RetVal = default(WindowResizeEdge);
      if (Application.Current.MainWindow.WindowState == WindowState.Maximized)
        return RetVal;

      Point CurPos = e.GetPosition(ShellRoot);
      if (CurPos.X < ResizeHandleWidth)
      {
        if (CurPos.Y < ResizeHandleWidth)
          RetVal = WindowResizeEdge.TopLeft;
        else if (CurPos.Y > ShellRoot.ActualHeight - ResizeHandleWidth)
          RetVal = WindowResizeEdge.BottomLeft;
        else
          RetVal = WindowResizeEdge.Left;
      }
      else if (CurPos.X > ShellRoot.ActualWidth - ResizeHandleWidth)
      {
        if (CurPos.Y < ResizeHandleWidth)
          RetVal = WindowResizeEdge.TopRight;
        else if (CurPos.Y > ShellRoot.ActualHeight - ResizeHandleWidth)
          RetVal = WindowResizeEdge.BottomRight;
        else
          RetVal = WindowResizeEdge.Right;
      }
      else
      {
        if (CurPos.Y < ResizeHandleWidth)
          RetVal = WindowResizeEdge.Top;
        else if (CurPos.Y > ShellRoot.ActualHeight - ResizeHandleWidth)
          RetVal = WindowResizeEdge.Bottom;
        else
          RetVal = default(WindowResizeEdge);
      }
      return RetVal;
    }
  } 
}
