﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;

namespace Recipe7_7.SD
{
  public class SpendingCollection : ObservableCollection<Spending>
  {
    public SpendingCollection()
    {
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 1,
        Item = "Utilities",
        Amount = 300
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 2,
        Item = "Food",
        Amount = 350
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 3,
        Item = "Clothing",
        Amount = 200
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 4,
        Item = "Transportation",
        Amount = 75
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 5,
        Item = "Mortgage",
        Amount = 3000
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 6,
        Item = "Education",
        Amount = 500
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 7,
        Item = "Entertainment",
        Amount = 125
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 8,
        Item = "Loans",
        Amount = 750
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 9,
        Item = "Medical",
        Amount = 80
      });
      this.Add(new Spending
      {
        ParentCollection = this,
        ID = 10,
        Item = "Miscellaneous",
        Amount = 175
      });
    }

    public double Total
    {
      get
      {
        return this.Sum(spending => spending.Amount);
      }
    }
  }

  [DataContract]
  public class Spending : INotifyPropertyChanged
  {

    public event PropertyChangedEventHandler PropertyChanged;
    internal void RaisePropertyChanged(PropertyChangedEventArgs e)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, e);
      }
    }

    public override int GetHashCode()
    {
      return ID.GetHashCode();
    }

    public override bool Equals(object obj)
    {
      return (obj is Spending) ? this.ID.Equals((obj as Spending).ID) : false;
    }

    SpendingCollection _ParentCollection = null;

    public SpendingCollection ParentCollection
    {
      get { return _ParentCollection; }
      set
      {
        _ParentCollection = value;
        if (ParentCollection != null)
        {
          foreach (Spending sp in ParentCollection)
            sp.RaisePropertyChanged(new PropertyChangedEventArgs("Amount"));
        }
      }
    }

    private int _ID = default(int);
    [DataMember]
    public int ID
    {
      get
      {
        return _ID;
      }

      set
      {
        if (value != _ID)
        {
          _ID = value;
          if (PropertyChanged != null) 
            PropertyChanged(this, new PropertyChangedEventArgs("ID"));
        }
      }
    }

    private string _Item;
    [DataMember]
    public string Item
    {
      get { return _Item; }
      set
      {
        string OldVal = _Item;
        if (OldVal != value)
        {
          _Item = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("Item"));

        }
      }
    }

    private double _Amount;
    [DataMember]
    public double Amount
    {
      get { return _Amount; }
      set
      {
        double OldVal = _Amount;
        if (OldVal != value)
        {
          _Amount = value;

          if (ParentCollection != null)
          {
            foreach (Spending sp in ParentCollection)
              sp.RaisePropertyChanged(new PropertyChangedEventArgs("Amount"));
          }
        }
      }
    }
  }
}
