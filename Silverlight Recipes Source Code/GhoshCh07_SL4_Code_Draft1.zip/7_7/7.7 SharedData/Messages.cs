﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Text;

namespace Recipe7_7.SD
{
  public enum MessageType
  {
    ItemRemoved,
    ItemsValueChanged
  }

  [DataContract]
  public class Message
  {
    [DataMember]
    public MessageType MsgType { get; set; }
    [DataMember]
    public List<Spending> Items { get; set; }

    public static string Serialize(Message Msg)
    {
      DataContractSerializer dcSer = new DataContractSerializer(typeof(Message));
      MemoryStream ms = new MemoryStream();
      dcSer.WriteObject(ms, Msg);
      ms.Flush();
      string RetVal = Encoding.UTF8.GetString(ms.GetBuffer(), 0, (int)ms.Length);
      ms.Close();
      return RetVal;
    }

    public static Message Deserialize(string Msg)
    {
      DataContractSerializer dcSer = new DataContractSerializer(typeof(Message));
      MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(Msg));
      Message RetVal = dcSer.ReadObject(ms) as Message;
      ms.Close();
      return RetVal;
    }
  }
}