﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Messaging;
using Recipe7_7.SD;

namespace Recipe7_7.HomeExpenseWorksheet
{
  public partial class MainPage : UserControl
  {
    //data source
    SpendingCollection SpendingList = new SpendingCollection();
    //create a sender
    LocalMessageSender WorksheetSender = 
      new LocalMessageSender("SpendingGraph",
        LocalMessageSender.Global);
    //create a receiver
    LocalMessageReceiver WorksheetReceiver =
      new LocalMessageReceiver("SpendingWorksheet",
        ReceiverNameScope.Global, LocalMessageReceiver.AnyDomain);

    public MainPage()
    {
      InitializeComponent();

      //bind data
      dgSpending.ItemsSource = SpendingList; 

      //handle message receipt
      WorksheetReceiver.MessageReceived+=
        new EventHandler<MessageReceivedEventArgs>((s,e) =>
      {
        //deserialize message
        Message Msg = Message.Deserialize(e.Message);
        //if item value changed
        if (Msg.MsgType == MessageType.ItemsValueChanged)
        {
          //for each item for which value has changed
          foreach (Spending sp in Msg.Items)
          {
            //find the corrsponding item in the data source and replace value
            SpendingList[SpendingList.IndexOf(sp)] = sp;
          }
        }        
      });

      //handle send completion
      WorksheetSender.SendCompleted += 
        new EventHandler<SendCompletedEventArgs>((s, e) =>
      {
        //if error
        if (e.Error != null)
        {
          //we had an error sending the message - do some error reporting here
        }
        //if there was a response
        else if (e.Response != null)
        {
          //the receiver sent a response - process it here
        }
      }); 
 
      //start listening for incoming messages
      WorksheetReceiver.Listen();      
    }

    //handle add row button click
    private void btnAddItem_Click(object sender, RoutedEventArgs e)
    {
      //add a new Spending instance to the data source
      SpendingList.Add(new Spending() { ParentCollection = SpendingList });
    }

    //handle a cell edit
    private void dgSpending_CellEditEnded(object sender,
      DataGridCellEditEndedEventArgs e)
    {
      //send a message
      WorksheetSender.SendAsync(Message.Serialize(
        new Message()
        {
          //message type - Item value changed
          MsgType = MessageType.ItemsValueChanged,
          //the changed Spending instance
          Items = new List<Spending> { e.Row.DataContext as Spending }
        }));
    }    

    //remove the selected item
    private void btnRemoveItem_Click(object sender, RoutedEventArgs e)
    {
      //if there is a selected row
      if (dgSpending.SelectedItem != null)
      {
        //get the corresponding Spending instance
        Spending target = dgSpending.SelectedItem as Spending;
        //remove it from the data source
        SpendingList.Remove(target);
        //send a message 
        WorksheetSender.SendAsync(Message.Serialize(
        new Message()
        {
          //message type - Item Removed
          MsgType = MessageType.ItemRemoved,
          //the item that was removed
          Items = new List<Spending> { target }
        })); 
      }
    }    
  }
}
