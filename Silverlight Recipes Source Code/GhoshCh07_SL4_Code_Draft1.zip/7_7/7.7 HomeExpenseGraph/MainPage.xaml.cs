﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Messaging;
using System.Windows.Shapes;
using Recipe7_7.SD;

namespace Recipe7_7.HomeExpenseGraph
{
  public partial class MainPage : UserControl
  {
    //variables to enable mouse interaction
    private bool MouseLeftBtnDown = false;
    private bool Dragging = false;
    Point PreviousPos;
    //data source
    SpendingCollection SpendingList = null;
    //create a sender
    LocalMessageSender GraphSender =
      new LocalMessageSender("SpendingWorksheet",
        LocalMessageSender.Global);
    //create a receiver
    LocalMessageReceiver GraphReceiver =
     new LocalMessageReceiver("SpendingGraph",
       ReceiverNameScope.Global, LocalMessageReceiver.AnyDomain);

    public MainPage()
    {
      InitializeComponent();

      SpendingList = this.Resources["REF_SpendingList"] as SpendingCollection;
      //handle property changed for each Spending - this is used to send item 
      //value changed messages
      foreach (Spending sp in SpendingList)
      {
        sp.PropertyChanged += 
          new System.ComponentModel.
            PropertyChangedEventHandler(Spending_PropertyChanged);
      }
      //handle message receipts
      GraphReceiver.MessageReceived += 
        new EventHandler<MessageReceivedEventArgs>((s, e) =>
      {
        //deserialize message
        Message Msg = Message.Deserialize(e.Message);
        //if value changed
        if (Msg.MsgType == MessageType.ItemsValueChanged)
        {
          //for each changed Spending instance
          foreach (Spending sp in Msg.Items)
          {            
            //if it exists
            if (SpendingList.Contains(sp))
            {
              //replace it with the changed one
              SpendingList[SpendingList.IndexOf(sp)] = sp;
            }
            else
            {
              //add the new one
              SpendingList.Add(sp);                     
            }
            //handle property changed
            sp.PropertyChanged += 
              new System.ComponentModel.
                PropertyChangedEventHandler(Spending_PropertyChanged);
            //force a recalc of the bars in the graph
            sp.ParentCollection = SpendingList;       
          }
        }
        //item removed
        else if (Msg.MsgType == MessageType.ItemRemoved)
        {
          foreach (Spending sp in Msg.Items)
          {            
            //unhook the event handler
            SpendingList[SpendingList.IndexOf(sp)].PropertyChanged 
              -= Spending_PropertyChanged;
            //remove from data source
            SpendingList.Remove(sp);
          }
          //force a recalc of the bars in the graph
          if (SpendingList.Count > 0) 
            SpendingList[0].ParentCollection = SpendingList;

        }        
      });

      //start listening for incoming messages
      GraphReceiver.Listen();
    }

    void Spending_PropertyChanged(object sender, 
      System.ComponentModel.PropertyChangedEventArgs e)
    {
      //send a message
      GraphSender.SendAsync(
        Message.Serialize(
            new Message
            {
              //changed item
              Items = new List<Spending> { sender as Spending },
              //message type - item value changed
              MsgType = MessageType.ItemsValueChanged
            }));

    } 

    private void Rectangle_MouseMove(object sender, MouseEventArgs e)
    {
      if (MouseLeftBtnDown)
      {
        Rectangle rect = (Rectangle)sender;
        if (Dragging == false)
        {
          Dragging = true;
          rect.CaptureMouse();
        }
        
        Point CurrentPos = e.GetPosition(sender as Rectangle);
        double Moved = CurrentPos.X - PreviousPos.X;
        if (rect.Width + Moved >= 0)
        {
          rect.Width += Moved;
        }
        PreviousPos = CurrentPos;
      }
    }

    private void Rectangle_MouseLeftButtonDown(object sender,
      MouseButtonEventArgs e)
    {
      MouseLeftBtnDown = true;
      PreviousPos = e.GetPosition(sender as Rectangle);
    }

    private void Rectangle_MouseLeftButtonUp(object sender,
      MouseButtonEventArgs e)
    {
      Rectangle rect = (Rectangle)sender;
      if (Dragging)
      {
        Dragging = false;
        rect.ReleaseMouseCapture();
      }
      MouseLeftBtnDown = false;
    }   
  }
}
