﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Ch02_ProgrammingModel.Recipe2_4
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void ButtonSelectFiles_Click(object sender, RoutedEventArgs e)
    {
      //Create dialog
      OpenFileDialog fileDlg = new OpenFileDialog();
      //Set file filter as desired
      fileDlg.Filter = "Tiff Files (*.tif)|*.tif|All Files (*.*)|*.*";
      fileDlg.FilterIndex = 1;
      //Allow multiple files to be selected (false by default)
      fileDlg.Multiselect = true;
      //Show Open File Dialog
      if (true == fileDlg.ShowDialog())
      {
        StatusLabel.Text =
            fileDlg.Files.Count() + " file(s) selected";
        foreach (var file in fileDlg.Files)
        {
          FileList.Items.Add(file.Name);
        }
      }
    }
  }
}