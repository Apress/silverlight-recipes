﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Text;

namespace Ch02_ProgrammingModel.Recipe2_14
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnSaveFile_Click(object sender, RoutedEventArgs e)
    {
      SaveFileDialog sfd = new SaveFileDialog();
      sfd.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
      sfd.FilterIndex = 1;
      if (true == sfd.ShowDialog())
      {
        using (Stream fs = sfd.OpenFile())
        {
          byte[] textFileBytes = (new UTF8Encoding(true)).GetBytes(
          "Welcome to Silverlight 3!!!! \r\n\r\nYour Authors,\r\n\r\nRob and Jit");
          fs.Write(textFileBytes, 0, textFileBytes.Length);
          fs.Close();
        }
      }
    }
  }
}
