﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Windows;
using System.Xml.Linq;

namespace Ch02_ProgrammingModel.Recipe2_12.Services
{
  public class ConfigurationSettingsService : IApplicationService, IApplicationLifetimeAware
  {
    //Event to allow the Application object know it is safe to create the MainPage UI
    //i.e. the ConfigurationSettingsService is fully populated
    public event EventHandler ConfigurationSettingsLoaded;

    #region IApplicationService Members
    void IApplicationService.StartService(ApplicationServiceContext context)
    {
      InitParams = context.ApplicationInitParams;
      LoadConfigSettings();
    }

    private void LoadConfigSettings()
    {
      if (InitParams["configUrl"] != "")
      {
        WebClient wc = new WebClient();
        wc.OpenReadCompleted += wc_OpenReadCompleted;
        wc.OpenReadAsync(new Uri(InitParams["configUrl"]));
      }
    }

    void IApplicationService.StopService()
    {
    }
    #endregion

    #region IApplicationLifetimeAware Members
    public void Exited()
    {
    }

    public void Exiting()
    {
    }

    public void Started()
    {
    }

    public void Starting()
    {
    }
    #endregion

    private void wc_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    {
      if (e.Error != null)
      {
        return;
      }
      using (Stream s = e.Result)
      {
        XDocument xDoc = XDocument.Load(s);
        ConfigSettings =
        (from setting in xDoc.Descendants("setting")
         select setting).ToDictionary(n => n.Element("key").Value, n => n.Element("value").Value);

        //Check to see if the event has any handler's attached
        //Fire event if that is the case
        if (ConfigurationSettingsLoaded != null)
          ConfigurationSettingsLoaded(this, EventArgs.Empty);
      }
    }

    //Store initialization parameters from <object> tag
    public Dictionary<string, string> InitParams { get; set; }
    //Stores configuraiton settings retrieved from web server
    public Dictionary<string, string> ConfigSettings { get; set; }
  }
}