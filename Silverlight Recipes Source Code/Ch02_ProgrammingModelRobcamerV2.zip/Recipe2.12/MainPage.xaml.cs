﻿using System.Windows;
using System.Windows.Controls;
using Ch02_ProgrammingModel.Recipe2_12.Services;


namespace Ch02_ProgrammingModel.Recipe2_12
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();

      this.Loaded += new RoutedEventHandler(MainPage_Loaded);
    }

    void MainPage_Loaded(object sender, RoutedEventArgs e)
    {
      ConfigurationSettingsService service = App.Current.ApplicationLifetimeObjects[0]
        as ConfigurationSettingsService;

      //Simple databind to the ConfigSettings Dictionary
      SettingsList.ItemsSource = service.ConfigSettings;
    }
  }
}
