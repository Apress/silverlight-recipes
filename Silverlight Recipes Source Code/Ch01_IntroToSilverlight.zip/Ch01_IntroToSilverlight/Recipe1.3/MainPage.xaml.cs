﻿using System.Windows.Controls;

namespace Ch01_IntroToSilverlight.Recipe1_3
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }
  }
}
