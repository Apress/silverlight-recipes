﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Ch03_DevelopingUX.Recipe3_7
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void Rect1_MouseEnter(object sender, MouseEventArgs e)
    {
      Rect1MouseMove.Begin();
    }

    private void Rect1_MouseLeave(object sender, MouseEventArgs e)
    {
      Rect1MouseMove.Begin();
    }

    private void Ellipse1_MouseEnter(object sender, MouseEventArgs e)
    {
      EllipseMouseEnter.Begin();
    }

    private void Ellipse1_MouseLeave(object sender, MouseEventArgs e)
    {
      EllipseMouseLeave.Begin();
    }

    private void Path_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      PathClick.Begin();
    }
  }
}