﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Windows.Media.Effects;

namespace Ch03_DevelopingUX.Recipe3_17.Views
{
  public partial class BuiltIn : Page
  {
    public BuiltIn()
    {
      InitializeComponent();
    }

    // Executes when the user navigates to this page.
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
    }
    private void BlurRadiusSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != DogImageGrid)
        ((BlurEffect)DogImageGrid.Effect).Radius = e.NewValue;
    }

    private void DropShadowBlurRadiusSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != DogImage)
        ((DropShadowEffect)DogImage.Effect).BlurRadius = e.NewValue;
    }

    private void EffectColor_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (null != DogImage)
        ((DropShadowEffect)DogImage.Effect).Color = (Color)e.AddedItems[0];
    }

    private void DropShadowShadowDepthSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != DogImage)
        ((DropShadowEffect)DogImage.Effect).ShadowDepth = e.NewValue;
    }

    private void DropShadowDirectionSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != DogImage)
        ((DropShadowEffect)DogImage.Effect).Direction = e.NewValue;
    }

    private void DropShadowOpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != DogImage)
        ((DropShadowEffect)DogImage.Effect).Opacity = e.NewValue;
    }
  }
}