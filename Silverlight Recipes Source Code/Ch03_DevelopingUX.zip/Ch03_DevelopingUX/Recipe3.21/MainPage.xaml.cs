﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Ch03_DevelopingUX.Recipe3_21
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnCut_Click(object sender, RoutedEventArgs e)
    {
      Clipboard.SetText(SourceText.SelectedText);
      SourceText.Text = SourceText.Text.Remove(SourceText.Text.IndexOf(SourceText.SelectedText), SourceText.SelectedText.Count());
    }

    private void btnCopy_Click(object sender, RoutedEventArgs e)
    {
      Clipboard.SetText(SourceText.SelectedText);
    }

    private void btnPaste_Click(object sender, RoutedEventArgs e)
    {
      DestinationText.Text += Clipboard.GetText();
    }
  }
}
