﻿using System.Windows;
using System.Windows.Controls;

namespace Ch03_DevelopingUX.Recipe3_4
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void rbShapes_Checked(object sender, RoutedEventArgs e)
    {
      ControlPlaceholder.Children.Add(new DrawingWithShapes());
    }

    private void rbPaths_Checked(object sender, RoutedEventArgs e)
    {
      ControlPlaceholder.Children.Add(new DrawingWithPaths());
    }

    private void rbGeometries_Checked(object sender, RoutedEventArgs e)
    {
      ControlPlaceholder.Children.Add(new DrawingWithGeometries());
    }
  }
}