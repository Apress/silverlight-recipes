﻿using System.Windows.Controls;

namespace Ch03_DevelopingUX.Recipe3_22
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
      textLeftToRight.Text = 
        "Lorem ipsum dolor sit amet, consectetur adipisicing \n"+
        "elit, sed do eiusmod tempor incididunt ut labore et \n"+
        "dolore magna aliqua. Ut enim ad minim veniam, quis \n"+
        "nostrud exercitation ullamco";

      textRightToLeft.Text = 
        "Lorem ipsum dolor sit amet, consectetur adipisicing \n" +
        "elit, sed do eiusmod tempor incididunt ut labore et \n" +
        "dolore magna aliqua. Ut enim ad minim veniam, quis \n" +
        "nostrud exercitation ullamco";
    }
  }
}
