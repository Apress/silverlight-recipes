﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Ch03_DevelopingUX.Recipe3_16
{
  public partial class MainPage : UserControl
  {
   public MainPage()
    {
      InitializeComponent();

    }

    private void btnDefaultAnimation_Click(object sender, RoutedEventArgs e)
    {
      EasingDoubleKeyFrame EasingKF = null;

      for (int i = 1; i < 7; i++)
      {
        EasingKF = LayoutRoot.FindName("PowerEase" + i.ToString()) 
          as EasingDoubleKeyFrame;
        EasingKF.EasingFunction = null;
      }

      for (int i = 1; i < 5; i++)
      {
        EasingKF = LayoutRoot.FindName("SineEase" + i.ToString()) 
          as EasingDoubleKeyFrame;
        EasingKF.EasingFunction = null;
      }
      RollingBallStoryboard.Begin();
    }

    private void btnBuiltInAnimation_Click(object sender, RoutedEventArgs e)
    {
      PowerEase pe = new PowerEase();
      pe.Power = 2;
      pe.EasingMode = EasingMode.EaseInOut;
      SineEase se = new SineEase();
      se.EasingMode = EasingMode.EaseInOut;
      EasingDoubleKeyFrame EasingKF = null ;

      for (int i = 1; i < 7; i++)
      {
        EasingKF = LayoutRoot.FindName("PowerEase" + i.ToString()) 
          as EasingDoubleKeyFrame;
        EasingKF.EasingFunction = pe;
      }

      for (int i = 1; i < 5; i++)
      {
        EasingKF = LayoutRoot.FindName("SineEase" + i.ToString()) 
          as EasingDoubleKeyFrame;
        EasingKF.EasingFunction = se;
      }
      RollingBallStoryboard.Begin();
    }

    private void btnCustomAnimation_Click(object sender, RoutedEventArgs e)
    {
      PowerEase pe = new PowerEase();
      pe.Power = 2;
      pe.EasingMode = EasingMode.EaseInOut;
      SineEase se = new SineEase();
      se.EasingMode = EasingMode.EaseInOut;
      EasingDoubleKeyFrame EasingKF = null;

      MyCustomEasingFunction mce = new MyCustomEasingFunction();

      for (int i = 1; i < 7; i++)
      {
        EasingKF = LayoutRoot.FindName("PowerEase" + i.ToString()) 
          as EasingDoubleKeyFrame;
        EasingKF.EasingFunction = null ;
      }

      for (int i = 1; i < 5; i++)
      {
        EasingKF = LayoutRoot.FindName("SineEase" + i.ToString()) 
          as EasingDoubleKeyFrame;
        EasingKF.EasingFunction = mce;
      }
      RollingBallStoryboard.Begin();
    }
   }
}
