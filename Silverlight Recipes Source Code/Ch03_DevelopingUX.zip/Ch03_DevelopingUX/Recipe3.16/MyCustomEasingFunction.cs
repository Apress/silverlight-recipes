﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Ch03_DevelopingUX.Recipe3_16
{
  public class MyCustomEasingFunction : EasingFunctionBase
  {
    public MyCustomEasingFunction()
      : base()
    {

    }

    protected override double EaseInCore(double normalizedTime)
    {
      return Math.Sqrt(normalizedTime);
    }
  }
}
