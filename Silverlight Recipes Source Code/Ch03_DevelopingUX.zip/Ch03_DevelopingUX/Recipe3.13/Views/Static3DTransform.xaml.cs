﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace Ch03_DevelopingUX.Recipe3_13.Views
{
  public partial class Static3DTransform : Page
  {
    public Static3DTransform()
    {
      InitializeComponent();
    }

    private void XaxisSlider_ValueChanged(object sender,
     RoutedPropertyChangedEventArgs<double> e)
    {
      ImageRotation.RotationX = e.NewValue;
    }
    private void YaxisSlider_ValueChanged(object sender,
      RoutedPropertyChangedEventArgs<double> e)
    {
      ImageRotation.RotationY = e.NewValue;
    }
    private void ZaxisSlider_ValueChanged(object sender,
      RoutedPropertyChangedEventArgs<double> e)
    {
      ImageRotation.RotationZ = e.NewValue;
    }
  }
}