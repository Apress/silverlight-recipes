﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace Ch03_DevelopingUX.Recipe3_13.Views
{
  public partial class Dynamic3DTransform : Page
  {
    bool blnPaused = false;

    public Dynamic3DTransform()
    {
      InitializeComponent();
    }

    // Executes when the user navigates to this page.
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
    }
    
    private void btnSpinPictures_Click(object sender, RoutedEventArgs e)
    {
      Spin3DStoryboard.RepeatBehavior = RepeatBehavior.Forever;
      Spin3DStoryboard.Begin();
      btnPauseContinuePictures.Visibility = Visibility.Visible;
    }

    private void btnPauseContinuePictures_Click(object sender, RoutedEventArgs e)
    {
      if (!blnPaused)
      {
        Spin3DStoryboard.Pause();
        btnPauseContinuePictures.Content = "Continue Spin";
        blnPaused = true;
      }
      else
      {
        Spin3DStoryboard.Resume();
        btnPauseContinuePictures.Content = "Pause Spin";
        blnPaused = false;
      }
    }
  }
}