﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.IO;

namespace Ch03_DevelopingUX.Recipe3_14
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }
    private void ButtonImportFile_Click(object sender, RoutedEventArgs e)
    {
      txtBlockWatermark.Visibility = Visibility.Collapsed;
      //Create dialog
      OpenFileDialog fileDlg = new OpenFileDialog();
      //Set file filter as desired
      fileDlg.Filter = "Png Files (*.png)|*.png|Jpeg Files (*.jpg)|*.jpg";
      fileDlg.FilterIndex = 1;
      //Allow multiple files to be selected (false by default)
      fileDlg.Multiselect = false;
      //Show Open File Dialog

      BitmapImage img = new BitmapImage();
      if (true == fileDlg.ShowDialog())
      {
        StatusLabel.Text =
            fileDlg.File.Name + "  selected";
        using (FileStream reader = fileDlg.File.OpenRead())
        {
          img.SetSource(reader);
        }
        ImageContent.Source = img;
      }
    }

    private void btnSaveCustomFile_Click(object sender, RoutedEventArgs e)
    {
      SaveFileDialog sfd = new SaveFileDialog();
      sfd.Filter = "sl3 Files (*.sl3)|*.sl3";
      sfd.FilterIndex = 1;

      WriteableBitmap bmp = new WriteableBitmap(ImageContainer, null);

      if (true == sfd.ShowDialog())
      {
        byte[] flattend = null;
        flattend = bmp.Pixels.SelectMany((p) => BitConverter.GetBytes(p)).ToArray();
        using (Stream fs = sfd.OpenFile())
        {
          fs.Write(flattend, 0, flattend.Length);
          fs.Flush();
          fs.Close();
        }
      }
    }

    private void btnOpenCustomFile_Click(object sender, RoutedEventArgs e)
    {
      txtBlockWatermark.Visibility = Visibility.Collapsed;
      OpenFileDialog fileDlg = new OpenFileDialog();
      fileDlg.Filter = "sl3 Files (*.sl3)|*.sl3";
      fileDlg.FilterIndex = 1;
      fileDlg.Multiselect = false;

      if (true == fileDlg.ShowDialog())
      {
        StatusLabel.Text =
            fileDlg.File.Name + "  selected";
        using (FileStream reader = fileDlg.File.OpenRead())
        {
          WriteableBitmap wrtBmp = null;
          wrtBmp = new WriteableBitmap(ImageContainer, null);
          byte[] fourBytes = new byte[4];

          int byteCounter = 0;
          int intCounter = 0;

          while (byteCounter < reader.Length - 1)
          {
            reader.Read(fourBytes, 0, 4);
            wrtBmp.Pixels[intCounter] = BitConverter.ToInt32(fourBytes, 0);
            intCounter++;
            byteCounter += 4;
          }
          ImageContent.Source = wrtBmp;
        }
      }
    }

    private void btnClearImage_Click(object sender, RoutedEventArgs e)
    {
      txtBlockWatermark.Visibility = Visibility.Collapsed;
      txtBlockWatermark.Text = "";
      ImageContent.Source = null;
    }

    private void btnAddWatermark_Click(object sender, RoutedEventArgs e)
    {
      txtBlockWatermark.Visibility = Visibility.Visible;
      txtBlockWatermark.Text = textWatermark.Text;
    }
  }
}
