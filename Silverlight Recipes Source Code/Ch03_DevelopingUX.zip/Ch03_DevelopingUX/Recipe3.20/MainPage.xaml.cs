﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Effects;

namespace Ch03_DevelopingUX.Recipe3_20
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void ImageEdit_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
      e.Handled = true;
    }

    private void ImageEdit_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
      pop.HorizontalOffset = e.GetPosition(null).X + 2;
      pop.VerticalOffset = e.GetPosition(null).Y + 2;
      pop.IsOpen = true;
    }

    private void SliderDropShadowBlur_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != ImageEdit)
        ((DropShadowEffect)ImageEdit.Effect).BlurRadius = e.NewValue;
    }

    private void SliderBlur_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != ContainerGrid)
        ((BlurEffect)ContainerGrid.Effect).Radius = e.NewValue;
    }

    private void ImageEdit_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      pop.IsOpen = false;
    }

    private void SliderDropShadowDepth_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      if (null != ImageEdit)
        ((DropShadowEffect)ImageEdit.Effect).ShadowDepth = e.NewValue;
    }
  }
}