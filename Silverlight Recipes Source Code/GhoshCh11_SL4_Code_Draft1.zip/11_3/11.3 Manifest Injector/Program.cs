﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;

namespace Recipe11_3
{
  class Program
  {
    static void Main(string[] args)
    {
      if (args.Count() < 2 || File.Exists(args[0]) == false || File.Exists(args[1]) == false || args[0].Contains(".ismc") == false)
      {
        Console.WriteLine("Usage: Recipe11_3.ManifestInjector <client manifest path> <content file path>");
        Console.ReadLine();
      }
      else
      {
        InsertContent(args[0], args[1]); 
      }
    }

    //inserts content from a XML data source file into a client manifest
    private static void InsertContent(string ClientManifestPath,
      string ContentDataSourceFilePath)
    {
      long TimeScale = 0;
      long TicksInASec = new TimeSpan(0, 0, 1).Ticks;
      //load client manifest
      XDocument xDocIsmc = XDocument.Load(ClientManifestPath);
      //load content data source file
      XDocument xDocContent = XDocument.Load(ContentDataSourceFilePath);
      //let's check to see if there is a video track
      XElement xeVideoStream = xDocIsmc.Root.Elements("StreamIndex").
        Where((xe) => xe.Attribute("Type") != null &&
          xe.Attribute("Type").Value == "video").FirstOrDefault();
      if (xeVideoStream == null) //nope
        return;
      else
      {
        //gett the existing timescale for the video track, or set to default 
        TimeScale = xeVideoStream.Attribute("TimeScale") != null ?
            long.Parse(xeVideoStream.Attribute("TimeScale").Value) :
            (xDocIsmc.Root.Attribute("TimeScale") != null ?
              long.Parse(xDocIsmc.Root.Attribute("TimeScale").Value) : 10000000);

        //add the streams
        xDocIsmc.Root.Add(
          xDocContent.Root.Elements("ContentTrack").
              Select((xeContentTrack) =>
              {
                return new XElement("StreamIndex",
                        new XAttribute("Type", "text"),
                        new XAttribute("Name",
                          xeContentTrack.Attribute("Name").Value),
                        new XAttribute("Subtype",
                          xeContentTrack.Attribute("Subtype").Value),
                        new XAttribute("TimeScale",
                          TimeScale.ToString()),
                        new XAttribute("ParentStreamIndex", "video"),
                        new XAttribute("ManifestOutput", "TRUE"),
                        new XAttribute("QualityLevels", "1"),
                        new XAttribute("Chunks", xeContentTrack.
                          Descendants("Event").Count().ToString()),
                        new XAttribute("Url",
                          string.Format("QualityLevels({{bitrate}},{{CustomAttributes}})/Fragments({0}={{start time}})",
                          xeContentTrack.Attribute("Name").Value)),
                        new XElement("QualityLevel",
                            new XAttribute("Index", "0"),
                            new XAttribute("Bitrate", "1000"),
                            new XAttribute("CodecPrivateData",
                              string.Empty),
                            new XAttribute("FourCC", string.Empty)
                            ),
                        xeContentTrack.Elements("Event").Select((xeEvent, idx) =>
                        {
                          return new XElement("c",
                                  new XAttribute("n", idx.ToString()),
                                  new XAttribute("t",
                                    TimeSpan.Parse(xeEvent.
                                      Attribute("time").Value).Ticks
                                      * TimeScale / TicksInASec),
                                  new XElement("f",
                                    System.Convert.
                                    ToBase64String(Encoding.UTF8.GetBytes(xeEvent.Value)))

                                  );
                        })

                      );
              }));

        xDocIsmc.Save(ClientManifestPath);

      }
    }
     
  }
}

