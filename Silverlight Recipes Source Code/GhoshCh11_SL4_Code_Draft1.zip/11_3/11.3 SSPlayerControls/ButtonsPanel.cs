﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.ComponentModel;
using Microsoft.Web.Media.SmoothStreaming;
using Microsoft.Web.Media;

namespace Recipe11_3
{
  [TemplatePart(Name = "btnPlayPause", Type = typeof(ButtonBase))]
  [TemplatePart(Name = "btnPrevFrame", Type = typeof(ButtonBase))]
  [TemplatePart(Name = "btnNextFrame", Type = typeof(ButtonBase))]
  [TemplateVisualState(GroupName = "PlayStates", Name = "Playing")]
  [TemplateVisualState(GroupName = "PlayStates", Name = "Paused")] 
  public class ButtonsPanel : Control, INotifyPropertyChanged
  {

    ButtonBase btnPlayPause = null;
    ButtonBase btnPrevFrame = null;
    ButtonBase btnNextFrame = null;
 

    public event EventHandler FrameForward;
    public event EventHandler FrameBackward; 

    private SmoothStreamingMediaElement _Viewer = default(SmoothStreamingMediaElement);

    public SmoothStreamingMediaElement Viewer
    {
      get
      {
        return _Viewer;
      }

      set
      {
        if (value != _Viewer)
        {
          _Viewer = value;
          Viewer.MediaOpened += new RoutedEventHandler((sender, args) =>
          {
            VisualStateManager.GoToState(this, "Paused", true);
          });
          _Viewer.CurrentStateChanged += new RoutedEventHandler((s, e) =>
          {
            if (_Viewer.CurrentState == SmoothStreamingMediaElementState.Paused)
            {
              VisualStateManager.GoToState(this, "Paused", true);
            }
            else if (_Viewer.CurrentState == SmoothStreamingMediaElementState.Playing)
            {
              VisualStateManager.GoToState(this, "Playing", true);
            }
          });
          if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Viewer"));
        }

      }
    }
     

    public ButtonsPanel()
    {
      base.DefaultStyleKey = typeof(ButtonsPanel);
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      btnPlayPause = GetTemplateChild("btnPlayPause") as ButtonBase;
      btnPrevFrame = GetTemplateChild("btnPrevFrame") as ButtonBase;
      btnNextFrame = GetTemplateChild("btnNextFrame") as ButtonBase; 
      if (btnPlayPause != null)
        btnPlayPause.Click += new RoutedEventHandler((sender, args) =>
        {
          if (Viewer != null && Viewer.CurrentState == SmoothStreamingMediaElementState.Paused)
          {
            Viewer.Play();
            VisualStateManager.GoToState(this, "Playing", true);
          }
          else
          {
            Viewer.Pause();
            VisualStateManager.GoToState(this, "Paused", true);
          }

        });
      if (btnPrevFrame != null)
        btnPrevFrame.Click += new RoutedEventHandler((sender, args) =>
        {
          if (FrameBackward != null)
            FrameBackward(this, EventArgs.Empty);

        });
      if (btnNextFrame != null)
        btnNextFrame.Click += new RoutedEventHandler((sender, args) =>
        {
          if (FrameForward != null)
            FrameForward(this, EventArgs.Empty);
        });
       
    }

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion
  }
}
