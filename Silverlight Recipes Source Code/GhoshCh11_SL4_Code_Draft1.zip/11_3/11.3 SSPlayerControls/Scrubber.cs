﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Web.Media.SmoothStreaming;
using Microsoft.Web.Media;

namespace Recipe11_3
{
  
  public class Scrubber : Slider, INotifyPropertyChanged
  {

    DispatcherTimer scrubberTimer = new DispatcherTimer();
    Thumb thumbMain = null;
    RepeatButton HorizontalTrackLargeChangeDecreaseRepeatButton = null;
    RepeatButton HorizontalTrackLargeChangeIncreaseRepeatButton = null;  
    private SmoothStreamingMediaElement _Viewer = default(SmoothStreamingMediaElement); 

    public SmoothStreamingMediaElement Viewer
    {
      get
      {
        return _Viewer;
      }

      set
      {
        if (value != _Viewer)
        {
          _Viewer = value;
          if (_Viewer != null)
          {  
            _Viewer.MediaOpened += new RoutedEventHandler((s, e) =>
            {
              this.Minimum = 0;
              this.Maximum = _Viewer.NaturalDuration.TimeSpan.TotalMilliseconds;
            });

            _Viewer.CurrentStateChanged += new RoutedEventHandler((sender, args) =>
            {
              switch (_Viewer.CurrentState)
              {

                case SmoothStreamingMediaElementState.Playing:
                  scrubberTimer.Start();
                  break;
                default: 
                  break;
              }
            });
          }
          if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs("Viewer"));
        }

      }
    }


    public Scrubber()
    {
      base.DefaultStyleKey = typeof(Scrubber);
    }
    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      thumbMain = GetTemplateChild("HorizontalThumb") as Thumb; 
      HorizontalTrackLargeChangeDecreaseRepeatButton = GetTemplateChild("HorizontalTrackLargeChangeDecreaseRepeatButton") as RepeatButton;
      HorizontalTrackLargeChangeIncreaseRepeatButton = GetTemplateChild("HorizontalTrackLargeChangeIncreaseRepeatButton") as RepeatButton; 

      
      if (thumbMain != null)
      {
        thumbMain.DragStarted += new DragStartedEventHandler((sender, args) =>
        {
          if (Viewer.CurrentState == SmoothStreamingMediaElementState.Playing)
          {
            if (scrubberTimer.IsEnabled) 
              scrubberTimer.Stop();
            if (Viewer.CurrentState != SmoothStreamingMediaElementState.Paused) 
              Viewer.Pause();
            Viewer.Position = TimeSpan.FromMilliseconds(this.Value);
          }
        });
      } 
      scrubberTimer.Tick += new EventHandler((sender, args) =>
      {
        if (Viewer != null) 
          this.Value = Viewer.Position.TotalMilliseconds;
      });
    }



    protected override void OnValueChanged(double oldValue, double newValue)
    {

      if (Viewer != null && Viewer.CurrentState != SmoothStreamingMediaElementState.Playing)
      {
        Viewer.Position = TimeSpan.FromMilliseconds(this.Value);
      } 
      base.OnValueChanged(oldValue, newValue); 
    }

    

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion
  }
}
