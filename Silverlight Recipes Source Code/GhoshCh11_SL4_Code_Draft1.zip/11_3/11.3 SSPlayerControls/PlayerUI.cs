﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Web.Media.SmoothStreaming;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Windows.Markup;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Browser;

namespace Recipe11_3
{

  public class PlayerUI : Control, INotifyPropertyChanged
  {
    Scrubber scrubber = null;
    ButtonsPanel buttonsPanel = null;
    Grid MediaElementContainer = null;
    internal SmoothStreamingMediaElement ssme = null;


    public string SmoothSource
    {
      get { return (string)GetValue(SmoothSourceProperty); }
      set { SetValue(SmoothSourceProperty, value); }
    }
    public static readonly DependencyProperty SmoothSourceProperty =
        DependencyProperty.Register("SmoothSource", typeof(string),
        typeof(PlayerUI), new PropertyMetadata(null,
          new PropertyChangedCallback(OnSmoothSourceChanged)));

    //Change handler for dependency property SmoothSourceProperty
    private static void OnSmoothSourceChanged(DependencyObject Src,
      DependencyPropertyChangedEventArgs Args)
    {
      PlayerUI thisObj = Src as PlayerUI;
      //act on the change...
      if (thisObj.ssme != null &&
        Uri.IsWellFormedUriString(Args.NewValue as string, UriKind.Absolute))
      {
        thisObj.SetMediaSource(Args.NewValue as string, thisObj.ssme);
      }
    }

    private void SetMediaSource(string MediaSourceUri,
      SmoothStreamingMediaElement ssme)
    {

      if (MediaSourceUri.Contains(".ism") || MediaSourceUri.Contains(".csm"))
        ssme.SmoothStreamingSource = new Uri(MediaSourceUri);
      else
        ssme.Source = new Uri(MediaSourceUri);
    }

    public PlayerUI()
    {
      base.DefaultStyleKey = typeof(PlayerUI);
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      ssme = GetTemplateChild("ssme") as SmoothStreamingMediaElement;
      scrubber = GetTemplateChild("scrubber") as Scrubber;
      buttonsPanel = GetTemplateChild("buttonsPanel") as ButtonsPanel;
      MediaElementContainer = GetTemplateChild("MediaElementContainer") as Grid;
      if (scrubber != null && ssme != null)
        scrubber.Viewer = ssme;
      if (buttonsPanel != null && ssme != null)
        buttonsPanel.Viewer = ssme;
      if (ssme != null)
      {
        ssme.ConfigPath = "config.xml";

        //use this in lieu of the TimelineEventReached handler
        //ssme.MediaOpened += new RoutedEventHandler((s, e) =>
        //{
        //  AddAndHandleMarkers();
        //});
        //handle TimelineEventReached
        ssme.TimelineEventReached += new EventHandler<TimelineEventArgs>((s, e) =>
        {
          //if closed caption event
          if (e.Track.ParentStream.Name.ToLower() == "closedcaptions" &&
            e.Track.ParentStream.Subtype.ToLower() == "capt")
          {
            //base64 decode the content and load the XML fragment
            XElement xElem = XElement.Parse(Encoding.UTF8.GetString(e.Event.EventData,
              0, e.Event.EventData.Length));
            //if we are adding a caption
            if (xElem.Attribute("Action") != null &&
              xElem.Attribute("Action").Value == "ADD")
            {
              //remove the text block if it exists
              UIElement captionTextBlock = MediaElementContainer.Children.
              Where((uie) => uie is FrameworkElement &&
                (uie as FrameworkElement).Name == (xElem.Attribute("Id").Value)).
                FirstOrDefault() as UIElement;
              if (captionTextBlock != null)
                MediaElementContainer.Children.Remove(captionTextBlock);


              //add a TextBlock 
              MediaElementContainer.Children.Add(new TextBlock()
              {
                Name = xElem.Attribute("Id").Value,
                Text = xElem.Value,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0, 0, 0, 20),
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 22
              });
            }
            //if we are removing a caption
            else if (xElem.Attribute("Action") != null &&
              xElem.Attribute("Action").Value == "REMOVE")
            {
              //remove the TextBlock
              MediaElementContainer.Children.Remove(MediaElementContainer.Children.
                Where((uie) => uie is FrameworkElement &&
                  (uie as FrameworkElement).Name == (xElem.Attribute("Id").Value)).
                  FirstOrDefault() as UIElement);
            }
          }
          //if animation event
          else if (e.Track.ParentStream.Name.ToLower() == "animations" &&
            e.Track.ParentStream.Subtype.ToLower() == "data")
          {
            //base64 decode the content and load the XML fragment
            XElement xElem = XElement.Parse(Encoding.UTF8.GetString(e.Event.EventData,
              0, e.Event.EventData.Length));
            //if we are adding the animation
            if (xElem.Attribute("Action") != null &&
              xElem.Attribute("Action").Value == "ADD")
            {
              //remove the Grid if it exists
              Grid AnimationContainer = MediaElementContainer.Children.
                  Where((uie) => uie is FrameworkElement && (uie as FrameworkElement).
                    Name == (xElem.Attribute("Id").Value)).
                    FirstOrDefault() as Grid;
              if (AnimationContainer != null)
                MediaElementContainer.Children.Remove(AnimationContainer);
              //add the animation to a grid overlay
              AnimationContainer = XamlReader.Load(xElem.Element(
               XName.Get("Grid",
               "http://schemas.microsoft.com/winfx/2006/xaml/presentation")).
               ToString(SaveOptions.DisableFormatting)) as Grid;
              AnimationContainer.Name = xElem.Attribute("Id").Value;
              MediaElementContainer.Children.Add(AnimationContainer);
              //load the animation
              Storyboard anim = AnimationContainer.Resources["SceneAnimation"] as
                Storyboard;
              //handle animation completion
              anim.Completed += new EventHandler((animSender, animargs) =>
              {
                //if animation is completed, remove it
                MediaElementContainer.Children.Remove(MediaElementContainer.Children.
                  Where((uie) => uie is FrameworkElement && (uie as FrameworkElement).
                    Name == (xElem.Attribute("Id").Value)).
                    FirstOrDefault() as UIElement);
              });
              //start the animation
              anim.Begin();
            }

          }
        }
        );
      }
    }

    private void AddAndHandleMarkers()
    {
      //get the Caption stream
      StreamInfo CCStream = ssme.AvailableStreams.Where((si) => 
        si.Name.ToLower() == "closedcaptions" && 
        si.Subtype.ToLower() == "capt").FirstOrDefault();
      //get the animation stream
      StreamInfo AnimStream = ssme.AvailableStreams.Where((si) => 
        si.Name.ToLower() == "animations" && 
        si.Subtype == "data").FirstOrDefault();
      //enumerate each TimelineEvent and add corresponding markers
      foreach (TimelineEvent te in CCStream.AvailableTracks[0].TrackData)
      {
        TimelineMarker tm = new TimelineMarker() 
        { Text = Encoding.UTF8.GetString(te.EventData, 0, te.EventData.Length), 
          Time = te.EventTime, Type = "CC" };
        ssme.Markers.Add(tm);
      }
      foreach (TimelineEvent te in AnimStream.AvailableTracks[0].TrackData)
      {
        TimelineMarker tm = new TimelineMarker() { 
          Text = Encoding.UTF8.GetString(te.EventData, 0, te.EventData.Length), 
          Time = te.EventTime, Type = "ANIM" };
        ssme.Markers.Add(tm);
      }
      //handle the markers when reached
      ssme.MarkerReached += new TimelineMarkerRoutedEventHandler((s, e) =>
      {
        XElement xElem = XElement.Parse(e.Marker.Text);

        //if closed caption event
        if (e.Marker.Type == "CC")
        {

          //if we are adding a caption
          if (xElem.Attribute("Action") != null &&
            xElem.Attribute("Action").Value == "ADD")
          {
            //add a TextBlock 
            MediaElementContainer.Children.Add(new TextBlock()
            {
              Name = xElem.Attribute("Id").Value,
              Text = xElem.Value,
              HorizontalAlignment = HorizontalAlignment.Center,
              VerticalAlignment = VerticalAlignment.Bottom,
              Margin = new Thickness(0, 0, 0, 20),
              Foreground = new SolidColorBrush(Colors.White),
              FontSize = 22
            });
          }
          //if we are removing a caption
          else if (xElem.Attribute("Action") != null &&
            xElem.Attribute("Action").Value == "REMOVE")
          {
            //remove the TextBlock
            MediaElementContainer.Children.Remove(MediaElementContainer.Children.
              Where((uie) => uie is FrameworkElement &&
                (uie as FrameworkElement).Name == (xElem.Attribute("Id").Value)).
                FirstOrDefault() as UIElement);
          }
        }
        //if animation event
        else if (e.Marker.Type == "ANIM")
        {

          //if we are adding the animation
          if (xElem.Attribute("Action") != null &&
            xElem.Attribute("Action").Value == "ADD")
          {
            //add the animation to a grid overlay
            Grid AnimationContainer = XamlReader.Load(xElem.Element(
              XName.Get("Grid", "http://schemas.microsoft.com/winfx/2006/xaml/presentation")).
              ToString(SaveOptions.DisableFormatting)) as Grid;
            AnimationContainer.Name = xElem.Attribute("Id").Value;
            MediaElementContainer.Children.Add(AnimationContainer);
            //load the animation
            Storyboard anim = AnimationContainer.Resources["SceneAnimation"] as
              Storyboard;
            //handle animation completion
            anim.Completed += new EventHandler((animSender, animargs) =>
            {
              //if animation is completed, remove it
              MediaElementContainer.Children.Remove(MediaElementContainer.Children.
                Where((uie) => uie is FrameworkElement && (uie as FrameworkElement).
                  Name == (xElem.Attribute("Id").Value)).
                  FirstOrDefault() as UIElement);
            });
            //start the animation
            anim.Begin();
          }

        }
      });
    }

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion
  }
}


