﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Web.Media.SmoothStreaming;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Windows.Markup;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Browser;

namespace Recipe11_5
{

  public class PlayerUI : Control, INotifyPropertyChanged
  {
    Scrubber scrubber = null;
    ButtonsPanel buttonsPanel = null;
    Grid MediaElementContainer = null;
    internal SmoothStreamingMediaElement ssme = null;


    public string SmoothSource
    {
      get { return (string)GetValue(SmoothSourceProperty); }
      set { SetValue(SmoothSourceProperty, value); }
    }
    public static readonly DependencyProperty SmoothSourceProperty =
        DependencyProperty.Register("SmoothSource", typeof(string),
        typeof(PlayerUI), new PropertyMetadata(null,
          new PropertyChangedCallback(OnSmoothSourceChanged)));

    //Change handler for dependency property SmoothSourceProperty
    private static void OnSmoothSourceChanged(DependencyObject Src,
      DependencyPropertyChangedEventArgs Args)
    {
      PlayerUI thisObj = Src as PlayerUI;
      //act on the change...
      if (thisObj.ssme != null &&
        Uri.IsWellFormedUriString(Args.NewValue as string, UriKind.Absolute))
      {
        thisObj.SetMediaSource(Args.NewValue as string, thisObj.ssme);
      }
    }

    private void SetMediaSource(string MediaSourceUri,
      SmoothStreamingMediaElement ssme)
    {

      if (MediaSourceUri.Contains(".ism") || MediaSourceUri.Contains(".csm"))
        ssme.SmoothStreamingSource = new Uri(MediaSourceUri);
      else
        ssme.Source = new Uri(MediaSourceUri);
    }

    public PlayerUI()
    {
      base.DefaultStyleKey = typeof(PlayerUI);
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      ssme = GetTemplateChild("ssme") as SmoothStreamingMediaElement;
      scrubber = GetTemplateChild("scrubber") as Scrubber;
      buttonsPanel = GetTemplateChild("buttonsPanel") as ButtonsPanel;
      MediaElementContainer = GetTemplateChild("MediaElementContainer") as Grid;
      if (scrubber != null && ssme != null)
        scrubber.Viewer = ssme;
      if (buttonsPanel != null && ssme != null)
        buttonsPanel.Viewer = ssme;
      if (ssme != null)
      {
        ssme.ConfigPath = "config.xml";

        ssme.MediaOpened += new RoutedEventHandler((s, e) =>
        {
          ScheduleClips();
        });
        ssme.ClipError += new EventHandler<ClipEventArgs>((s, e) =>
        {
          string a = "b";
        });
         
      }
    }

    /** UNCOMMENT TO Schedule clips in a chained fashion **/

    //private void ScheduleClips()
    //{
    //  StreamInfo siAdClips = ssme.AvailableStreams.
    //    Where(si => si.Name.ToLower() == "adclips").
    //      FirstOrDefault();
    //  if (siAdClips != null && siAdClips.AvailableTracks.Count > 0)
    //  {
    //    ClipContext clipCtx = null;
    //    foreach (TimelineEvent te in siAdClips.AvailableTracks[0].TrackData)
    //    {
    //      XElement xeClipData = XElement.Parse(
    //        Encoding.UTF8.GetString(te.EventData, 0,te.EventData.Length));
    //      //if this is the first clip to be scheduled
    //      if (clipCtx == null)
    //      {
    //        clipCtx = ssme.ScheduleClip(
    //            new ClipInformation
    //            {
    //              ClickThroughUrl = 
    //                new Uri(xeClipData.Attribute("ClickThruUri").Value),
    //              ClipUrl = 
    //                new Uri(xeClipData.Attribute("Uri").Value),
    //              IsSmoothStreamingSource = 
    //                xeClipData.Attribute("Uri").Value.ToUpper().Contains("ISM"),
    //              Duration = 
    //                TimeSpan.Parse(xeClipData.Attribute("Duration").Value)
    //            },
    //            te.EventTime, //pass in the start time for the clip
    //            true,
    //            null);
    //      }
    //      else //subsequent clips
    //      {
    //        clipCtx = ssme.ScheduleClip(
    //            new ClipInformation
    //            {
    //              ClickThroughUrl = 
    //                new Uri(xeClipData.Attribute("ClickThruUri").Value),
    //              ClipUrl = 
    //                new Uri(xeClipData.Attribute("Uri").Value),
    //              IsSmoothStreamingSource = 
    //                xeClipData.Attribute("Uri").Value.ToUpper().Contains("ISM"),
    //              Duration = TimeSpan.Parse(xeClipData.Attribute("Duration").Value)
    //            },
    //          //pass in the clip context for the previous scheduled clip to chain
    //            clipCtx, 
    //            true,
    //            null);
    //      }
    //    } 
    //  }
    //}

    /** Schedule clips at absolute timepoints **/
    private void ScheduleClips()
    {       
      //get the clip data stream
      StreamInfo siAdClips = ssme.AvailableStreams.
        Where(si => si.Name.ToLower() == "adclips").FirstOrDefault();
      //if we have tracks
      if (siAdClips != null && siAdClips.AvailableTracks.Count > 0)
      {
        //for each event in that track
        foreach (TimelineEvent te in siAdClips.AvailableTracks[0].TrackData)
        {
          //parse the inner XML fragment
          XElement xeClipData = XElement.Parse(
            Encoding.UTF8.GetString(te.EventData, 0, te.EventData.Length));
          //schedule the clip
          ssme.ScheduleClip(
              new ClipInformation
              {
                ClickThroughUrl = 
                  new Uri(xeClipData.Attribute("ClickThruUri").Value),
                ClipUrl = 
                  new Uri(xeClipData.Attribute("Uri").Value),
                IsSmoothStreamingSource = 
                  xeClipData.Attribute("Uri").Value.ToUpper().Contains("ISM"),
                Duration = 
                  TimeSpan.Parse(xeClipData.Attribute("Duration").Value)
              },
              te.EventTime,
              true, //pause the timeline
              null);
        }    
      }
    }

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion
  }
}


