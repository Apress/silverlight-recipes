﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;

namespace ManifestInjector
{
  class Program
  {
    static void Main(string[] args)
    {
      if (args.Count() < 2 || File.Exists(args[0]) == false || File.Exists(args[1]) == false || args[0].Contains(".ismc") == false)
      {
        Console.WriteLine("Usage: ContentAdder <client manifest path> <content file path>");
        Console.ReadLine();
      }
      else
      {
        
        CreateExternalManifests(Path.GetDirectoryName(args[0]), args[1]); 
      }
    } 
    //inserts content from a XML data source file into a client manifest
    private static void CreateExternalManifests(string ClientManifestPath, string ContentDataSourceFilePath)
    {
      long TimeScale = 10000000;
      long TicksInASec = new TimeSpan(0, 0, 1).Ticks;

      //load content data source file
      XDocument xDocContent = XDocument.Load(ContentDataSourceFilePath);

      foreach (XElement manifestElement in xDocContent.Root.Elements("Manifest"))
      {
        XDocument xDocIsmc = new XDocument();

        xDocIsmc.Add(new XElement("SmoothStreamingMedia",new XAttribute("Duration","0"),

        manifestElement.Elements("ContentTrack").
              Select((xeContentTrack) =>
              {
                return new XElement("StreamIndex",
                        new XAttribute("Type", "text"),
                        new XAttribute("Name",
                          xeContentTrack.Attribute("Name").Value),
                        new XAttribute("Subtype",
                          xeContentTrack.Attribute("Subtype").Value),
                        new XAttribute("TimeScale",
                          TimeScale.ToString()),
                        new XAttribute("ParentStreamIndex", "video"),
                        new XAttribute("ManifestOutput", "TRUE"),
                        new XAttribute("QualityLevels", "1"),
                        new XAttribute("Chunks", xeContentTrack.
                          Descendants("Event").Count().ToString()),
                        new XAttribute("Url",
                          string.Format("QualityLevels({{bitrate}},{{CustomAttributes}})/Fragments({0}={{start time}})",
                          xeContentTrack.Attribute("Name").Value)),
                        new XElement("QualityLevel",
                            new XAttribute("Index", "0"),
                            new XAttribute("Bitrate", "1000"),
                            new XAttribute("CodecPrivateData",
                              string.Empty),
                            new XAttribute("FourCC", string.Empty)
                            ),
                        xeContentTrack.Elements("Event").Select((xeEvent, idx) =>
                        {
                          return new XElement("c",
                                  new XAttribute("n", idx.ToString()),
                                  new XAttribute("t",
                                    TimeSpan.Parse(xeEvent.
                                      Attribute("time").Value).Ticks
                                      * TimeScale / TicksInASec),
                                  new XElement("f",
                                    System.Convert.
                                    ToBase64String(Encoding.UTF8.GetBytes(xeEvent.Value)))

                                  );
                        })

                      );
              })));

        string TargetPath = Path.Combine(ClientManifestPath, manifestElement.Attribute("RelativePath").Value);
        string DirPath = Path.GetDirectoryName(TargetPath);
        if (Directory.Exists(DirPath) == false)
          Directory.CreateDirectory(DirPath);

        FileStream fs =  (File.Exists(TargetPath)) ? new FileStream(TargetPath, FileMode.Truncate) : new FileStream(TargetPath, FileMode.CreateNew); 
        xDocIsmc.Save(fs);
        fs.Close();
      }



    }
  }
}

