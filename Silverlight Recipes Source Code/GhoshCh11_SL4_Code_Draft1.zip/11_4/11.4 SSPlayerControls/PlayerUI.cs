﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Web.Media.SmoothStreaming;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Windows.Markup;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Browser;
using System.Threading;

namespace Recipe11_4
{

  public class PlayerUI : Control, INotifyPropertyChanged
  {
    Scrubber scrubber = null;
    ButtonsPanel buttonsPanel = null;
    Grid MediaElementContainer = null;
    internal SmoothStreamingMediaElement ssme = null;
    AutoResetEvent evt = new AutoResetEvent(false);

    public string SmoothSource
    {
      get { return (string)GetValue(SmoothSourceProperty); }
      set { SetValue(SmoothSourceProperty, value); }
    }
    public static readonly DependencyProperty SmoothSourceProperty =
        DependencyProperty.Register("SmoothSource", typeof(string),
        typeof(PlayerUI), new PropertyMetadata(null,
          new PropertyChangedCallback(OnSmoothSourceChanged)));

    //Change handler for dependency property SmoothSourceProperty
    private static void OnSmoothSourceChanged(DependencyObject Src,
      DependencyPropertyChangedEventArgs Args)
    {
      PlayerUI thisObj = Src as PlayerUI;
      //act on the change...
      if (thisObj.ssme != null &&
        Uri.IsWellFormedUriString(Args.NewValue as string, UriKind.Absolute))
      {
        thisObj.SetMediaSource(Args.NewValue as string, thisObj.ssme);
      }
    }

    private void SetMediaSource(string MediaSourceUri,
      SmoothStreamingMediaElement ssme)
    {

      if (MediaSourceUri.Contains(".ism"))
        ssme.SmoothStreamingSource = new Uri(MediaSourceUri);
      else
        ssme.Source = new Uri(MediaSourceUri);
    }

    public PlayerUI()
    {
      base.DefaultStyleKey = typeof(PlayerUI);
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      ssme = GetTemplateChild("ssme") as SmoothStreamingMediaElement;
      scrubber = GetTemplateChild("scrubber") as Scrubber;
      buttonsPanel = GetTemplateChild("buttonsPanel") as ButtonsPanel;
      MediaElementContainer = GetTemplateChild("MediaElementContainer") as Grid;
      if (scrubber != null && ssme != null)
        scrubber.Viewer = ssme;
      if (buttonsPanel != null && ssme != null)
        buttonsPanel.Viewer = ssme;
      if (ssme != null)
      {
        ssme.ConfigPath = "config.xml";

      ssme.ManifestMerge +=
        new SmoothStreamingMediaElement.ManifestMergeHandler((sender) =>
        {
          object ParsedExternalManifest = null;
          //URI of the right external manifest based on current locale
          //for example expands to          
          string UriString = string.Format(
            "http://localhost/SmoothStreaming/Media/FighterPilot/{0}/CC.xml",
            CultureInfo.CurrentCulture.Name);
          //parse the external manifest - time out in 3 secs
          ssme.ParseExternalManifest(new Uri(UriString), 3000, out ParsedExternalManifest);
          //merge the external manifest
          ssme.MergeExternalManifest(ParsedExternalManifest);
          
        });

        ssme.MediaOpened += new RoutedEventHandler((s, e) =>
         {
           AddAndHandleMarkers();
         });

          
      }
    } 


    private void AddAndHandleMarkers()
    {
      //get the Caption stream
      StreamInfo CCStream = ssme.AvailableStreams.Where((si) => 
        si.Name.ToLower() == "closedcaptions" && 
        si.Subtype.ToLower() == "capt").FirstOrDefault();
      
      //enumerate each TimelineEvent and add corresponding markers
      foreach (TimelineEvent te in CCStream.AvailableTracks[0].TrackData)
      {
        TimelineMarker tm = new TimelineMarker() 
        { Text = Encoding.UTF8.GetString(te.EventData, 0, te.EventData.Length), 
          Time = te.EventTime, Type = "CC" };
        ssme.Markers.Add(tm);
      }
       
      //handle the markers when reached
      ssme.MarkerReached += new TimelineMarkerRoutedEventHandler((s, e) =>
      {
        XElement xElem = XElement.Parse(e.Marker.Text);

        //if closed caption event
        if (e.Marker.Type == "CC")
        {

          //if we are adding a caption
          if (xElem.Attribute("Action") != null &&
            xElem.Attribute("Action").Value == "ADD")
          {
            //add a TextBlock 
            MediaElementContainer.Children.Add(new TextBlock()
            {
              Name = xElem.Attribute("Id").Value,
              Text = xElem.Value,
              HorizontalAlignment = HorizontalAlignment.Center,
              VerticalAlignment = VerticalAlignment.Bottom,
              Margin = new Thickness(0, 0, 0, 20),
              Foreground = new SolidColorBrush(Colors.White),
              FontSize = 22
            });
          }
          //if we are removing a caption
          else if (xElem.Attribute("Action") != null &&
            xElem.Attribute("Action").Value == "REMOVE")
          {
            //remove the TextBlock
            MediaElementContainer.Children.Remove(MediaElementContainer.Children.
              Where((uie) => uie is FrameworkElement &&
                (uie as FrameworkElement).Name == (xElem.Attribute("Id").Value)).
                FirstOrDefault() as UIElement);
          }
        }
         
      });
    }

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion
  }
}


