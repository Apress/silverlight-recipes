﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Recipe10_9
{
  public partial class MainPage : UserControl
  {
    VideoBrush vidbrush = new VideoBrush();
    CaptureSource webcamCapture = new CaptureSource();
    WebCamMSS mss = null;
    WebCamVideoSink vSink = new WebCamVideoSink();
    WebCamAudioSink aSink = new WebCamAudioSink();

    public MainPage()
    {
      InitializeComponent();

      this.Loaded += new RoutedEventHandler(MainPage_Loaded);
    }

    void MainPage_Loaded(object sender, RoutedEventArgs e)
    {

      webcamCapture.VideoCaptureDevice = 
        CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice();
      webcamCapture.AudioCaptureDevice = 
        CaptureDeviceConfiguration.GetDefaultAudioCaptureDevice();     
      mss = new WebCamMSS(meWebCamOut,vSink, aSink);
      mss.WebCamSource = webcamCapture;

      vidbrush.SetSource(webcamCapture);
      webcamDirectCapture.Background = vidbrush;

      vSink.FormatChanged += 
        new EventHandler<VideoFormatChangedEventArgs>(vSink_FormatChanged);
     
    }
    private void BtnCaptureStartStop_Click(object sender, RoutedEventArgs e)
    {
      if (webcamCapture.State == CaptureState.Stopped)
      {

        if (CaptureDeviceConfiguration.AllowedDeviceAccess ||
          CaptureDeviceConfiguration.RequestDeviceAccess())
          webcamCapture.Start();
      }
      else if (webcamCapture.State == CaptureState.Started)
        webcamCapture.Stop();
    }

    void vSink_FormatChanged(object sender, VideoFormatChangedEventArgs e)
    {
      this.Dispatcher.BeginInvoke(new Action(() =>
      {
        //correct for negative stride
        if (e.Format.Stride < 0)
        {
          brdrMediaElement.Projection = new PlaneProjection()
          {
            CenterOfRotationX = 0.5,
            RotationX = 180
          };
        }
      }));
    }    
  }
}
