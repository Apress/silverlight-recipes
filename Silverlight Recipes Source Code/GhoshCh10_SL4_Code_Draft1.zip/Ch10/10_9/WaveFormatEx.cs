﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using System.Text;
using System.Globalization;

namespace Recipe10_9
{
  public class WaveFormatEx
  {
    public static ushort WAVE_FORMAT_PCM = 1;
    private ushort _FormatTag = WAVE_FORMAT_PCM;

    public ushort FormatTag
    {
      get
      {
        return _FormatTag;
      }

      set
      {
        if (value != _FormatTag)
        {
          _FormatTag = value;
        }
      }
    }

    private ushort _Channels = default(ushort);
    public ushort Channels
    {
      get
      {
        return _Channels;
      }

      set
      {
        if (value != _Channels)
        {
          _Channels = value;
        }
      }
    }

    private uint _SamplesPerSecond = default(uint);
    public uint SamplesPerSecond
    {
      get
      {
        return _SamplesPerSecond;
      }

      set
      {
        if (value != _SamplesPerSecond)
        {
          _SamplesPerSecond = value;
        }
      }
    }



    private uint _AverageBytesPerSecond = default(uint);
    //For PCM format
    //AverageBytesPerSecond = SamplesPerSecond * BlockAlignmentInBytes
    public uint AverageBytesPerSecond
    {
      get
      {
        return FormatTag == WAVE_FORMAT_PCM ? 
          SamplesPerSecond * BlockAlignmentInBytes : _AverageBytesPerSecond;
      }

      set
      {
        
        if (value != _AverageBytesPerSecond && FormatTag != WAVE_FORMAT_PCM)
        {
          _AverageBytesPerSecond = value;
        }

      }
    }



    private ushort _BlockAlignmentInBytes = default(ushort);
    //For PCM format, 
    //BlockAlignmentInBytes = (Channels * BitsPerSample) / 8
    public ushort BlockAlignmentInBytes
    {
      get
      {
        return FormatTag == WAVE_FORMAT_PCM ? 
          (ushort)((Channels * BitsPerSample) / 8) : _BlockAlignmentInBytes;
      }

      set
      {
        if (value != _BlockAlignmentInBytes && FormatTag != WAVE_FORMAT_PCM)
        {
          _BlockAlignmentInBytes = value;
        }

      }
    }
    
    private ushort _BitsPerSample = default(ushort);
    public ushort BitsPerSample
    {
      get
      {
        return _BitsPerSample;
      }

      set
      {
        if (value != _BitsPerSample)
        {
          if (FormatTag == WAVE_FORMAT_PCM && value != 8 && value != 16)
            throw new Exception(
              "For PCM format sample size needs to be either 8 or 16 bits"
              );
          _BitsPerSample = value;
        }

      }
    }


    //Ignored for PCM format
    private ushort _Size = 0;
    public ushort Size
    {
      get
      {
        return _Size;
      }

      set
      {
        if (value != _Size)
        {
          _Size = value;
        }

      }
    }

    public string ToCodecDataString()
    { 
      return new StringBuilder()
        .Append(string.Format(CultureInfo.InvariantCulture, "{0:X4}", this.FormatTag).HexStringToLittleEndianByteOrder())
        .Append(string.Format(CultureInfo.InvariantCulture, "{0:X4}", this.Channels).HexStringToLittleEndianByteOrder())
        .Append(string.Format(CultureInfo.InvariantCulture, "{0:X8}", this.SamplesPerSecond).HexStringToLittleEndianByteOrder())
        .Append(string.Format(CultureInfo.InvariantCulture, "{0:X8}", this.AverageBytesPerSecond).HexStringToLittleEndianByteOrder())
        .Append(string.Format(CultureInfo.InvariantCulture, "{0:X4}", this.BlockAlignmentInBytes).HexStringToLittleEndianByteOrder())
        .Append(string.Format(CultureInfo.InvariantCulture, "{0:X4}", this.BitsPerSample).HexStringToLittleEndianByteOrder())
        .Append(string.Format(CultureInfo.InvariantCulture, "{0:X4}", this.Size).HexStringToLittleEndianByteOrder()).ToString();
    }
  }

  public static class StringStaticExtensions
  {
    public static string HexStringToLittleEndianByteOrder(this String thisObj)
    {
      if (thisObj.Length % 2 != 0)
        return null;
      else
      {
        char[] Chars = thisObj.ToCharArray();
        var EvenChars = Chars.Where((ch, idx) => idx % 2 == 0).ToList();
        var OddChars = Chars.Where((ch, idx) => idx % 2 != 0).ToList();
        var a = EvenChars.Select((ch, idx) => new char[] { EvenChars[idx], OddChars[idx] }).ToList();
        a.Reverse();
        string retval = new string(a.SelectMany((charr) => charr).ToArray());
        return retval;
      }
    }
  }
}
