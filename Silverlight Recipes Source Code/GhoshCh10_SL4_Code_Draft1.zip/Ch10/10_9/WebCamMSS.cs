﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Controls;
using System.Windows.Media;

namespace Recipe10_9
{
  public class WebCamMSS : MediaStreamSource
  {
     
    WebCamVideoSink vsink = null;
    WebCamAudioSink asink = null;
    

    private Dictionary<MediaSourceAttributesKeys, string> mediaSourceAttributes =
      new Dictionary<MediaSourceAttributesKeys, string>();
    private List<MediaStreamDescription> availableMediaStreams =
      new List<MediaStreamDescription>();
    private Dictionary<MediaSampleAttributeKeys, string> videoSampleAttributes =
      new Dictionary<MediaSampleAttributeKeys, string>();
 
    bool VideoFormatSelected = false;
    bool AudioFormatSelected = false;

    Queue<VideoSample> VideoSampleBuffer = new Queue<VideoSample>();
    Queue<AudioSample> AudioSampleBuffer = new Queue<AudioSample>();
    object VideoBufferCritSec = new object();
    object AudioBufferCritSec = new object();
    internal ManualResetEvent AudioSampleRequest = new ManualResetEvent(false);
    internal ManualResetEvent VideoSampleRequest = new ManualResetEvent(false);
    internal AutoResetEvent AudioSampleArrived = new AutoResetEvent(false);
    internal AutoResetEvent VideoSampleArrived = new AutoResetEvent(false);

    private MediaElement meTarget = null;

    private CaptureSource _WebCamSource = default(CaptureSource);
    public CaptureSource WebCamSource
    {
      get
      {
        return _WebCamSource;
      }

      set
      {
        if (value != _WebCamSource)
        {
          _WebCamSource = value;  
          //attach the sinks to the capture source
          vsink.CaptureSource = _WebCamSource;          
          asink.CaptureSource = _WebCamSource; 
        
        }
      }
    }

    public WebCamMSS(MediaElement target, WebCamVideoSink vSink,
     WebCamAudioSink aSink)
    {

      meTarget = target;
      vsink = vSink;
      asink = aSink;

      //handle the various sink events
      vsink.FormatChanged +=
          new EventHandler<VideoFormatChangedEventArgs>(VideoSink_FormatChanged);
      vsink.SampleGenerated +=
        new EventHandler<VideoSampleEventArgs>(VideoSink_SampleGenerated);
      asink.FormatChanged +=
        new EventHandler<AudioFormatChangedEventArgs>(AudioSink_FormatChanged);
      asink.SampleGenerated +=
      new EventHandler<AudioSampleEventArgs>(AudioSink_SampleGenerated);

      //cannot seek and duration is infinite
      mediaSourceAttributes.Add(MediaSourceAttributesKeys.CanSeek,
        false.ToString());
      mediaSourceAttributes.Add(MediaSourceAttributesKeys.Duration,
        TimeSpan.MaxValue.Ticks.ToString());

      //create the background workers to handle incoming samples
      BackgroundWorker VideoSampleDispatch = new BackgroundWorker();
      BackgroundWorker AudioSampleDispatch = new BackgroundWorker();

      VideoSampleDispatch.DoWork +=
        new DoWorkEventHandler(VideoSampleDispatch_DoWork);
      AudioSampleDispatch.DoWork +=
        new DoWorkEventHandler(AudioSampleDispatch_DoWork);
      //run the background workers
      VideoSampleDispatch.RunWorkerAsync(this);
      AudioSampleDispatch.RunWorkerAsync(this);
    } 

    void AudioSink_FormatChanged(object sender, AudioFormatChangedEventArgs e)
    {
      //switch context to the thread the MSS was created on (UI thread)
      meTarget.Dispatcher.BeginInvoke(new Action(() =>
          {
            if (_WebCamSource.AudioCaptureDevice != null)
            {
              //set the audio capture device format
              _WebCamSource.AudioCaptureDevice.DesiredFormat = e.Format;
              //create WaveFormatEx instance and populate from format information
              WaveFormatEx wfex = new WaveFormatEx()
              {
                //bits per sample
                BitsPerSample = (ushort)e.Format.BitsPerSample,
                //always PCM
                FormatTag = WaveFormatEx.WAVE_FORMAT_PCM,
                //channel count
                Channels = (ushort)e.Format.Channels,
                //samples per sec
                SamplesPerSecond = (uint)e.Format.SamplesPerSecond
              };
              //add WaveFormatEx as codec private data
              availableMediaStreams.Add(
                new MediaStreamDescription(MediaStreamType.Audio,
                  new Dictionary<MediaStreamAttributeKeys, string>()
                {
                  {MediaStreamAttributeKeys.CodecPrivateData,
                    wfex.ToCodecDataString()}
                }));
              //set flag to indicate audio format processing is done
              AudioFormatSelected = true;
            }

            if (VideoFormatSelected && AudioFormatSelected)
            {
              //if both formats have been processed, 
              //attach the MSS to the MediaElement
              meTarget.SetSource(this);
            }
          }
      ));
    }

    void VideoSink_FormatChanged(object sender, VideoFormatChangedEventArgs e)
    {
      //switch context to the thread the MSS was created on (UI thread)
      meTarget.Dispatcher.BeginInvoke(new Action(() =>
      {
        if (_WebCamSource.VideoCaptureDevice != null)
        {
          //set the video capture device format
          _WebCamSource.VideoCaptureDevice.DesiredFormat = e.Format;
          //add stream attributes
          availableMediaStreams.Add(
            new MediaStreamDescription(MediaStreamType.Video,
                new Dictionary<MediaStreamAttributeKeys, string>() 
              { 
                //FourCC code - we are processing 32 bit RGBA saqmples
                {MediaStreamAttributeKeys.VideoFourCC,"RGBA"},
                //frame height
                {MediaStreamAttributeKeys.Height,e.Format.PixelHeight.ToString()},
                //frame width
                {MediaStreamAttributeKeys.Width,e.Format.PixelWidth.ToString()},
                //not need for codec private data - RGBA is uncompressed
                {MediaStreamAttributeKeys.CodecPrivateData,String.Empty} 
              }
              )
            );
          //add sample attributes - frame height and frame width
          videoSampleAttributes.Add(MediaSampleAttributeKeys.FrameHeight,
            e.Format.PixelHeight.ToString());
          videoSampleAttributes.Add(MediaSampleAttributeKeys.FrameWidth,
            e.Format.PixelWidth.ToString());
          //set format selection flag
          VideoFormatSelected = true;
        }

        //if both formats are set
        if (VideoFormatSelected && AudioFormatSelected)
        {
          //attach MSS to ME
          meTarget.SetSource(this);
        }
      }));
    }
 
    void VideoSink_SampleGenerated(object sender, VideoSampleEventArgs e)
    {
      lock (VideoBufferCritSec)
      {
        //enque the audio sample
        VideoSampleBuffer.Enqueue(e.Sample);
      }
      //signal sample arrival
      this.VideoSampleArrived.Set();
    }
    void AudioSink_SampleGenerated(object sender, AudioSampleEventArgs e)
    {
      lock (AudioBufferCritSec)
      {
        //enque the audio sample
        AudioSampleBuffer.Enqueue(e.Sample);
      }
      //signal sample arrival
      this.AudioSampleArrived.Set();
    }

    protected override void GetSampleAsync(MediaStreamType mediaStreamType)
    {
      if (mediaStreamType == MediaStreamType.Audio)
      {
        //signal audio sample request to sample processing loop
        AudioSampleRequest.Set();
      }
      else if (mediaStreamType == MediaStreamType.Video)
      {
        //signal video sample request to sample processing loop
        VideoSampleRequest.Set();
      }
    }

    void AudioSampleDispatch_DoWork(object sender, DoWorkEventArgs e)
    {
      //keep running  
      while (true)
      {
        //wait for sample request
        this.AudioSampleRequest.WaitOne();
        //request arrived - is there a sample to dispatch ?
        if (this.AudioSampleBuffer.Count > 0)
        {
          AudioSample audSample = null;
          lock (this.AudioBufferCritSec)
          {
            //dequeue sample
            audSample = this.AudioSampleBuffer.Dequeue();
          }
          //flatten sample and report sample 
          MemoryStream msAud = new MemoryStream(audSample.SampleData);
          ReportGetSampleCompleted(
            new MediaStreamSample(availableMediaStreams.
              Where((msd) => msd.Type == MediaStreamType.Audio).First(),
              msAud, 0, audSample.SampleData.Length, 
              audSample.SampleTime, new Dictionary<MediaSampleAttributeKeys,
                string>()));
          //reset wait handle
          this.AudioSampleRequest.Reset();
        }
        else
        {
          //wait for sample arrival
          this.AudioSampleArrived.WaitOne();
        }

      }
    }

    void VideoSampleDispatch_DoWork(object sender, DoWorkEventArgs e)
    {
      //keep running  
      while (true)
      {
        this.VideoSampleRequest.WaitOne();
        //request arrived - is there a sample to dispatch ?
        if (this.VideoSampleBuffer.Count > 0)
        {
          VideoSample vidSample = null;
          lock (this.VideoBufferCritSec)
          {
            //dequeue sample
            vidSample = this.VideoSampleBuffer.Dequeue();
          }

          //flatten sample and report sample 
          MemoryStream msVid = new MemoryStream(vidSample.SampleData);
          ReportGetSampleCompleted(
            new MediaStreamSample(availableMediaStreams.
              Where((msd) => msd.Type == MediaStreamType.Video).First(),
              msVid, 0, vidSample.SampleData.Length, vidSample.SampleTime,
              vidSample.FrameDuration, videoSampleAttributes));
          //reset wait handle
          this.VideoSampleRequest.Reset();
        }
        else
        {
          //wait for sample arrival
          this.VideoSampleArrived.WaitOne();
        }

      }
    }
    protected override void CloseMedia()
    {
      return;
    }

    protected override void GetDiagnosticAsync(
      MediaStreamSourceDiagnosticKind diagnosticKind)
    {
      return;
    }   

    protected override void OpenMediaAsync()
    {
      ReportOpenMediaCompleted(mediaSourceAttributes, availableMediaStreams);
    }

    protected override void SeekAsync(long seekToTime)
    {
      ReportSeekCompleted(0);
    }

    protected override void SwitchMediaStreamAsync(
      MediaStreamDescription mediaStreamDescription)
    {
      return;
    } 
  }


}
