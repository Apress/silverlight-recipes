﻿using System;
using System.Windows.Media;

namespace Recipe10_9
{
  public class WebCamVideoSink : VideoSink
  {
    //events to be raised in response to various capture lifecycle phases
    internal event EventHandler CaptureStarted;
    internal event EventHandler CaptureStopped;
    internal event EventHandler<VideoFormatChangedEventArgs> FormatChanged;
    internal event EventHandler<VideoSampleEventArgs> SampleGenerated;

    protected override void OnCaptureStarted()
    {
      if (CaptureStarted != null) CaptureStarted(this, EventArgs.Empty);
    }

    protected override void OnCaptureStopped()
    {
      if (CaptureStopped != null) CaptureStopped(this, EventArgs.Empty);
    }

    protected override void OnFormatChange(VideoFormat videoFormat)
    {
      if (FormatChanged != null)
        FormatChanged(this,
          new VideoFormatChangedEventArgs() { Format = videoFormat });
    }

    protected override void OnSample(long sampleTimeInHundredNanoseconds,
      long frameDurationInHundredNanoseconds, byte[] sampleData)
    {
      if (SampleGenerated != null)
        SampleGenerated(this,
          new VideoSampleEventArgs()
          {
            Sample = new VideoSample()
            {
              SampleTime = sampleTimeInHundredNanoseconds,
              FrameDuration = frameDurationInHundredNanoseconds,
              SampleData = sampleData
            }
          });
    }
  }

  public class WebCamAudioSink : AudioSink
  {
    internal event EventHandler CaptureStarted;
    internal event EventHandler CaptureStopped;
    internal event EventHandler<AudioFormatChangedEventArgs> FormatChanged;
    internal event EventHandler<AudioSampleEventArgs> SampleGenerated;

    protected override void OnCaptureStarted()
    {
      if (CaptureStarted != null) CaptureStarted(this, EventArgs.Empty);
    }

    protected override void OnCaptureStopped()
    {
      if (CaptureStopped != null) CaptureStopped(this, EventArgs.Empty);
    }

    protected override void OnFormatChange(AudioFormat audioFormat)
    {
      if (FormatChanged != null)
        FormatChanged(this,
          new AudioFormatChangedEventArgs() { Format = audioFormat });
    }

    protected override void OnSamples(long sampleTimeInHundredNanoseconds,
      long sampleDurationInHundredNanoseconds, byte[] sampleData)
    {
      if (SampleGenerated != null)
        SampleGenerated(this,
          new AudioSampleEventArgs()
          {
            Sample = new AudioSample()
            {
              SampleTime = sampleTimeInHundredNanoseconds,
              SampleDuration = sampleDurationInHundredNanoseconds,
              SampleData = sampleData
            }
          });
    }
  }

  public class VideoSample 
  {
    public long SampleTime { get; set; }
    public long FrameDuration { get; set; }
    public byte[] SampleData { get; set; } 
  }

  public class AudioSample
  {
    public long SampleTime { get; set; }
    public long SampleDuration { get; set; }
    public byte[] SampleData { get; set; } 
  }

  public class VideoFormatChangedEventArgs : EventArgs
  {
    public VideoFormat Format { get; set; }
  }
  public class AudioFormatChangedEventArgs : EventArgs
  {
    public AudioFormat Format { get; set; }
  }

  public class VideoSampleEventArgs : EventArgs
  {
    public VideoSample Sample { get; set; }
  }

  public class AudioSampleEventArgs : EventArgs
  {
    public AudioSample Sample { get; set; }
  }
}
