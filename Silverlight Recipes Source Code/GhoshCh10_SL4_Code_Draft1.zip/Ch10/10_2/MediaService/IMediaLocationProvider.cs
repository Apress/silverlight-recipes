﻿using System.ServiceModel;
using System.ServiceModel.Web;
using System.Xml;

namespace Recipe10_2
{  
  [ServiceContract]
  public interface IMediaLocationProvider
  {
    [WebGet]
    [OperationContract]
    [XmlSerializerFormat]
    XmlDocument GetLocationList();    
  }  
}
