﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace Recipe10_8
{
  public partial class MainPage : UserControl
  {

    
   
    public MainPage()
    {
      InitializeComponent();
      this.Loaded += new RoutedEventHandler(MainPage_Loaded);
    }

    //collection to hold all the still images
    ObservableCollection<WriteableBitmap> obscollSnapsTaken =
      new ObservableCollection<WriteableBitmap>();

    void MainPage_Loaded(object sender, RoutedEventArgs e)
    {
      //populate the video device combobox with all available 
      //video capture devices
      cbxVideoDevices.ItemsSource = 
        new ObservableCollection<VideoCaptureDevice>(
          CaptureDeviceConfiguration.GetAvailableVideoCaptureDevices());
      //populate the audio device combobox with all available 
      //video capture devices
      cbxAudioDevices.ItemsSource = 
        new ObservableCollection<AudioCaptureDevice>(
          CaptureDeviceConfiguration.GetAvailableAudioCaptureDevices());
      //set the itemscontrol for still images to a blank collection
      itmctrlSnappedPics.ItemsSource = obscollSnapsTaken; 
    }

    //currently attached CaptureSource
    CaptureSource currentCaptureSource = null;

    private void btnStartCamera_Click(object sender, RoutedEventArgs e)
    {
      //if the capture source is not null and there is an ongoing capture
      //lets stop it
      if (currentCaptureSource != null && 
        currentCaptureSource.State == CaptureState.Started)
        currentCaptureSource.Stop();

      //initialize new capture source
      //set VideoCaptureDevice with the user selected one or the default 
      //if none selected. Do the same with the AudioCaptureDevice
      currentCaptureSource = new CaptureSource()
      {
        VideoCaptureDevice = cbxVideoDevices.SelectedItem == null ? 
          CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice() :
          cbxVideoDevices.SelectedItem as VideoCaptureDevice,
        AudioCaptureDevice = cbxAudioDevices.SelectedItem == null ? 
          CaptureDeviceConfiguration.GetDefaultAudioCaptureDevice() : 
          cbxAudioDevices.SelectedItem as AudioCaptureDevice
      };

      //if device access has been successfully requested before
      //of if not , and this device access request is unsuccessful as well
      //return
      if (!CaptureDeviceConfiguration.AllowedDeviceAccess && 
        CaptureDeviceConfiguration.RequestDeviceAccess() == false)
        return;

      //access granted - start capture
      currentCaptureSource.Start();
      //create a VideoBrush
      VideoBrush captureBrush = new VideoBrush() 
      { 
        Stretch = Stretch.Fill 
      };
      //set the videobrush to use the CaptureSource
      captureBrush.SetSource(currentCaptureSource);
      //paint a border background with the videobrush
      brdrOutput.Background = captureBrush;
      //handle the CaptureImageCompleted for still images
      currentCaptureSource.CaptureImageCompleted +=
        new EventHandler<CaptureImageCompletedEventArgs>((s, args) =>
      {
        //add the image taken (WriteableBitmap) to the host collection
        obscollSnapsTaken.Add(args.Result);
      });
    }

    private void btnSnapPic_Click(object sender, RoutedEventArgs e)
    {
      //capture a still image
      currentCaptureSource.CaptureImageAsync();
    }

    private void btnVideoDeviceProperties_Click(object sender, RoutedEventArgs e)
    {
      //use either the selected video capture device or the default one if none 
      //is selected
      VideoCaptureDevice Device = cbxVideoDevices.SelectedItem == null ? 
        CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice() 
        : cbxVideoDevices.SelectedItem as VideoCaptureDevice;
      //create a child window with a title
      ChildWindow cwDeviceProperties = new ChildWindow() 
      { 
        Title = 
        string.Format("Properties - {0}", 
        Device.FriendlyName) , Height=300, Width=400
      };
      //set the child window content to a content control
      //bind the content control to the list of supported formats
      //set the content template to the data template for displaying 
      //video formats
      cwDeviceProperties.Content = new ContentControl() 
      { 
        Content = Device.SupportedFormats, 
        ContentTemplate = this.Resources["dtVideoDeviceProperty"] as DataTemplate
      };
      //show the child window
      cwDeviceProperties.Show();
    }

    private void btnAudioDeviceProperties_Click(object sender, RoutedEventArgs e)
    {
      AudioCaptureDevice Device = cbxAudioDevices.SelectedItem == null ?
        CaptureDeviceConfiguration.GetDefaultAudioCaptureDevice()
        : cbxAudioDevices.SelectedItem as AudioCaptureDevice;
      ChildWindow cwDeviceProperties = new ChildWindow()
      {
        Title =
        string.Format("Properties - {0}",
        Device.FriendlyName),
        Height = 300,
        Width = 400
      };

      cwDeviceProperties.Content = new ContentControl() { Content = Device.SupportedFormats, 
        ContentTemplate = this.Resources["dtAudioDeviceProperty"] as DataTemplate };
      cwDeviceProperties.Show();
    }

  }


  public class DefaultDeviceIndicatorConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      bool val = (bool)value;
      return val ? "DefaultDevice.png" : null;
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }

}
