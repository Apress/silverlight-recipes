﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading; 

namespace Recipe10_7
{

  
  public partial class MainPage : UserControl
  {

    private DispatcherTimer sliderTimer = new DispatcherTimer();
    private Thumb SliderThumb = null;
    public MainPage()
    {
      InitializeComponent();

      me.MediaFailed += new EventHandler<ExceptionRoutedEventArgs>(me_MediaFailed);
      me.MediaOpened += new RoutedEventHandler(me_MediaOpened);
      me.CurrentStateChanged += new RoutedEventHandler(me_CurrentStateChanged);
      sliderTimer.Interval = TimeSpan.FromMilliseconds(100);
      sliderTimer.Tick += new EventHandler(sliderTimer_Tick);      

    }
 

    private void HandleSliderThumbDrag()
    {
      if (SliderThumb == null)
      {
        SliderThumb = VisualTreeHelper.FindElementsInHostCoordinates(
          sliderSeek.TransformToVisual(Application.Current.RootVisual).
          TransformBounds(new Rect(0, 0, sliderSeek.ActualWidth, 
            sliderSeek.ActualHeight))
          , sliderSeek).Where((uie) => uie is Thumb).FirstOrDefault() as Thumb;

        SliderThumb.DragStarted += new DragStartedEventHandler((s, args) =>
        {
          if (me.CurrentState == MediaElementState.Playing)
          {
            me.Pause();
          }
        });
      }
    }

    void me_CurrentStateChanged(object sender, RoutedEventArgs e)
    {
      switch (me.CurrentState)
      {
        case MediaElementState.Playing:
          sliderTimer.Start();
          break;
        default:
          sliderTimer.Stop();
          break;

      }
    }

     

    void me_MediaOpened(object sender, RoutedEventArgs e)
    {
      HandleSliderThumbDrag();
      me.Play();
    }

    void sliderTimer_Tick(object sender, EventArgs e)
    {
      sliderSeek.Value = me.Position.TotalMilliseconds * 100 
        / me.NaturalDuration.TimeSpan.TotalMilliseconds;
    }

    void me_MediaFailed(object sender, ExceptionRoutedEventArgs e)
    {
      System.Diagnostics.Debug.WriteLine("{0} - {1}",e.ErrorException.Message,
        e.ErrorException.StackTrace);
    }

    private void btnPlay_Click(object sender, RoutedEventArgs e)
    {
      if (me.CurrentState == MediaElementState.Paused)
        me.Play();
      else
      {
        OpenFileDialog ofd = new OpenFileDialog() { Multiselect = false };
        if (ofd.ShowDialog() == true)
        {
          FileStream filestream = ofd.File.OpenRead();
          BitmapToVideoMediaStreamSource mss = 
            new BitmapToVideoMediaStreamSource(filestream);
          me.SetSource(mss); 
        }
      }
      
    }

    private void sliderSeek_ValueChanged(object sender,
      RoutedPropertyChangedEventArgs<double> e)
    {
      if (me.CurrentState == MediaElementState.Paused)
      {       
        me.Position = TimeSpan.FromTicks((long)e.NewValue *
          me.NaturalDuration.TimeSpan.Ticks  / 100);
      }
    }

    private void btnPause_Click(object sender, RoutedEventArgs e)
    {
      me.Pause();
    }
  }
}
