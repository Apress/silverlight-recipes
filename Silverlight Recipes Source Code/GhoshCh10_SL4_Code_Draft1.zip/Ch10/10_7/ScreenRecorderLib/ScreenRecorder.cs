﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Recipe10_7
{
  public class ScreenRecorder
  {
    private DispatcherTimer snapshotTimer = new DispatcherTimer();
    List<WriteableBitmap> Buffer1 = new List<WriteableBitmap>();
    List<WriteableBitmap> Buffer2 = new List<WriteableBitmap>();
    List<WriteableBitmap> CurrentBuffer = null;
    List<WriteableBitmap> FlushBuffer = null;   
    private long TotalFrameCounter = 0;
    private long FlushCounter = 0;
    private double RenderHeight;
    private double RenderWidth;
    private object WriterLock = new Object();
    private MediaInfo Info = new MediaInfo();
    private Transform BitmapTransform = null;
    private int FrameRate = default(int);

    private Stream _TempFile = null;
    
    public Stream TempFile
    {
      get { return _TempFile; }
      set { _TempFile = value; }
    }


    

    private UIElement _RecordingRoot = default(UIElement);
    public UIElement RecordingRoot
    {
      get
      {
        if (_RecordingRoot == null)
          _RecordingRoot = Application.Current.RootVisual;
        return _RecordingRoot;
      }

      set
      { 
        _RecordingRoot = value; 
      }
    }

    private double _FrameHeight = 180;
    public double FrameHeight
    {
      get
      {
        return _FrameHeight;
      }

      set
      {
        _FrameHeight = value;  
      }
    }

    private double _FrameWidth = 320;
    public double FrameWidth
    {
      get
      {
        return _FrameWidth;
      }

      set
      {         
        _FrameWidth = value;
      }
    }

    public ScreenRecorder(int FrameRate)
    {
      this.FrameRate = FrameRate; 
      snapshotTimer.Interval = new TimeSpan(1000*10000/FrameRate);
      snapshotTimer.Tick += new EventHandler(snapshotTimer_Tick);
    }

    public void Start()
    {
      CurrentBuffer = Buffer1; 
      snapshotTimer.Start();

      if (TempFile != null)
      {
        byte[] MediaInfoSizePlaceHolder = BitConverter.GetBytes(Int32.MaxValue);
        TempFile.Write(MediaInfoSizePlaceHolder, 0, 
          MediaInfoSizePlaceHolder.Length);
      }
    } 
   
    public void Stop()
    {
      if (snapshotTimer != null && snapshotTimer.IsEnabled) snapshotTimer.Stop();
      if (TempFile != null)
      {
        lock (WriterLock)
        {
          TempFile.Flush();

          MediaInfo Info = new MediaInfo { FrameCount = TotalFrameCounter, 
            FrameHeight = this.FrameHeight, FrameWidth = this.FrameWidth, 
            FrameRate = this.FrameRate };
          DataContractSerializer ser = 
            new DataContractSerializer(typeof(MediaInfo));
          MemoryStream ms = new MemoryStream();
          ser.WriteObject(ms, Info);
          ms.Flush();
          Byte[] Buff = ms.GetBuffer();
          TempFile.Write(Buff, 0, Buff.Length);
          TempFile.Seek(0L, SeekOrigin.Begin);
          Byte[] BuffLength = BitConverter.GetBytes(Buff.Length);
          TempFile.Write(BuffLength, 0, BuffLength.Length);
          TempFile.Close();
        }
      }    
    }

    void snapshotTimer_Tick(object sender, EventArgs e)
    {

      if (FlushCounter + 1 > FrameRate && Monitor.TryEnter(WriterLock))
      {
        TotalFrameCounter += FlushCounter;       
        FlipBackBuffer();
        Monitor.Exit(WriterLock);
      }
      else
        FlushCounter++;

      if (RenderHeight == 0 || RenderWidth == 0)
      {
        RenderWidth = (int)RecordingRoot.RenderSize.Width;
        RenderHeight = (int)RecordingRoot.RenderSize.Height;
        if (RenderHeight != 0 && RenderWidth != 0)
           BitmapTransform = new ScaleTransform() { CenterX = 0, CenterY = 0,
             ScaleY = FrameHeight / RenderHeight, 
             ScaleX = FrameWidth / RenderWidth }; 
      }
      if (RenderHeight != 0 && RenderWidth != 0)
      { 
          WriteableBitmap capture = 
            new WriteableBitmap(RecordingRoot, BitmapTransform);
          CurrentBuffer.Add(capture); 
      }
    }

    private void FlipBackBuffer()
    {

      CurrentBuffer = (CurrentBuffer == Buffer1) ? Buffer2 : Buffer1;
      FlushBuffer = (FlushBuffer == Buffer1) ? Buffer2 : Buffer1;
      CurrentBuffer.Clear();
      FlushCounter = 0;
      if (TempFile != null)
      {
        BackgroundWorker bwFlusher = new BackgroundWorker();
        bwFlusher.DoWork += new DoWorkEventHandler(bwFlusher_DoWork);
        bwFlusher.RunWorkerAsync(FlushBuffer);
      }
      return;
    }

    void bwFlusher_DoWork(object sender, DoWorkEventArgs e)
    {
      lock (WriterLock)
      {
        List<WriteableBitmap> Buffer = e.Argument as List<WriteableBitmap>;
        byte[] Flattened = null;
        int PixelCount = (int)FrameHeight * (int)FrameWidth;
        for (int i = 0; i < Buffer.Count; i++)
        {
          Flattened = Buffer[i].Pixels.
            SelectMany((p) => BitConverter.GetBytes(p)).ToArray();
          TempFile.Write(Flattened, 0, Flattened.Length);
        }
        TempFile.Flush();
        Buffer.Clear();
      }
    }
  }

  public class MediaInfo
  {
    public int FrameRate { get; set; }
    public double FrameHeight { get; set; }
    public double FrameWidth { get; set; }
    public long FrameCount { get; set; }
  }

}
