﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Windows.Media;
using System.Threading;

namespace Recipe10_7
{
  public class BitmapToVideoMediaStreamSource : MediaStreamSource
  {
    public Stream MediaStream { get; set; }
    internal MediaInfo mediaInfo { get; set; }

    Dictionary<MediaStreamAttributeKeys, string> mediaStreamAttributes =
      new Dictionary<MediaStreamAttributeKeys, string>();

    Dictionary<MediaSourceAttributesKeys, string> mediaSourceAttributes =
      new Dictionary<MediaSourceAttributesKeys, string>();

    List<MediaStreamDescription> mediaStreamDescriptions = new
      List<MediaStreamDescription>();

    Dictionary<MediaSampleAttributeKeys, string> mediaSampleAttributes =
      new Dictionary<MediaSampleAttributeKeys, string>();

    private long lastFrame = 0;
    private long FrameSize = 0;
    private double FrameDuration = 0;
    private int HdrSizeByteLength = BitConverter.GetBytes(Int32.MaxValue).Length;
    private int HdrByteLength = 0;

    private BitmapToVideoMediaStreamSource()
    {
    }

    public BitmapToVideoMediaStreamSource(Stream media)
    {
      this.MediaStream = media;
      ParseMediaStream(MediaStream);
    }

    private void ParseMediaStream(Stream MediaStream)
    {
      //read the size of the MediaInfo header information
      MediaStream.Seek(0L, SeekOrigin.Begin);

      Byte[] HdrSizeBuff = new Byte[HdrSizeByteLength];
      MediaStream.Read(HdrSizeBuff, 0, HdrSizeByteLength);
      HdrByteLength = BitConverter.ToInt32(HdrSizeBuff, 0);
      Byte[] MediaInfoBuff = new Byte[HdrByteLength];

      MediaStream.Seek(MediaStream.Length - HdrByteLength, SeekOrigin.Begin);
      MediaStream.Read(MediaInfoBuff, 0, HdrByteLength);
      byte[] TrimmedBuff = MediaInfoBuff.Reverse().SkipWhile((b) => 
        Convert.ToInt32(b) == 0).Reverse().ToArray();
      MemoryStream ms = new MemoryStream(TrimmedBuff);
      DataContractSerializer ser = new DataContractSerializer(typeof(MediaInfo));
      mediaInfo = ser.ReadObject(ms) as MediaInfo;
    }

    protected override void CloseMedia()
    {
      MediaStream.Close();
    }

    protected override void GetDiagnosticAsync(MediaStreamSourceDiagnosticKind
      diagnosticKind)
    {

    }

    protected override void GetSampleAsync(MediaStreamType mediaStreamType)
    {
      if (lastFrame > mediaInfo.FrameCount)
      {
        MediaStreamDescription msd = 
          new MediaStreamDescription(MediaStreamType.Video, mediaStreamAttributes);
        MediaStreamSample mediaSample =
          new MediaStreamSample(msd, null, 0, 0, 0, mediaSampleAttributes);
      }
      else
      {
        MediaStreamDescription msd = 
          new MediaStreamDescription(MediaStreamType.Video, mediaStreamAttributes);
        MediaStreamSample mediaSample = 
          new MediaStreamSample(msd, MediaStream, (lastFrame * FrameSize) + 
            HdrSizeByteLength, FrameSize, 
            (long)(lastFrame * FrameDuration), mediaSampleAttributes);
        lastFrame++;
        ReportGetSampleCompleted(mediaSample);
      }

    } 

    protected override void OpenMediaAsync()
    {
      lastFrame = 0;
      FrameSize = (long)(mediaInfo.FrameHeight * mediaInfo.FrameWidth * 4);
      FrameDuration = TimeSpan.FromMilliseconds(1000 / mediaInfo.FrameRate).Ticks;

      mediaSourceAttributes.Add(MediaSourceAttributesKeys.CanSeek, true.ToString());
      mediaSourceAttributes.Add(MediaSourceAttributesKeys.Duration, 
        ((long)(mediaInfo.FrameCount * FrameDuration)).ToString());

      mediaStreamAttributes.Add(MediaStreamAttributeKeys.Height, 
        mediaInfo.FrameHeight.ToString());
      mediaStreamAttributes.Add(MediaStreamAttributeKeys.Width,
        mediaInfo.FrameWidth.ToString());
      mediaStreamAttributes.Add(MediaStreamAttributeKeys.CodecPrivateData, "");
      mediaStreamAttributes.Add(MediaStreamAttributeKeys.VideoFourCC, "RGBA");

      mediaStreamDescriptions.Add(new MediaStreamDescription(MediaStreamType.Video,
        mediaStreamAttributes)); 

      mediaSampleAttributes.Add(MediaSampleAttributeKeys.FrameHeight,
        mediaInfo.FrameHeight.ToString());
      mediaSampleAttributes.Add(MediaSampleAttributeKeys.FrameWidth,
        mediaInfo.FrameWidth.ToString());

      MediaStream.Seek(HdrSizeByteLength, SeekOrigin.Begin);
      ReportOpenMediaCompleted(mediaSourceAttributes, mediaStreamDescriptions);

    }

    protected override void SeekAsync(long seekToTime)
    {      
      //find the corresponding frame
      lastFrame = (long)(mediaInfo.FrameRate * 
        TimeSpan.FromTicks(seekToTime).TotalSeconds) + HdrSizeByteLength;
      this.ReportSeekCompleted(seekToTime);
    }

    protected override void SwitchMediaStreamAsync(MediaStreamDescription
      mediaStreamDescription)
    {

    } 

  } 

}
