﻿function loadFlyoutView()
{
}