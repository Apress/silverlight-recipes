﻿function Xaml1DoReceive(data)
{
    document.getElementById("Xaml1").Content.MainPage.ReceiveData(data);
}

function Xaml1RequestData() {
    return document.getElementById("Xaml1").Content.MainPage.RequestData();
}

function Xaml2DoReceive(data)
{
    document.getElementById("Xaml2").Content.MainPage.ReceiveData(data);
}

function Xaml2RequestData(data) 
{
    return document.getElementById("Xaml2").Content.MainPage.RequestData();
}