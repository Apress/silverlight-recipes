﻿function onSilverlightLoaded(sender, args) {
    //get the plugin
    var slPlugin = document.getElementById("Xaml1");
    //create a new List<string> managed type instance
    var MyList = slPlugin.Content.BarObject.createManagedObject("List<string>");
    //add some values
    MyList.push("Rob","Jit","Harry");
    //call the method passing in the parameter
    slPlugin.Content.BarObject.Foo(MyList);

    //Get Color from Page.GetMyColor
    colorRGB = document.getElementById("Xaml1").Content.MainPage.GetMyBackgroundColor();
    //Obtain a reference to the html input textbox
    txt1 = document.getElementById("Text1");
    txt1.value = colorRGB;
    txt1.style.backgroundColor = colorRGB;
    //Set background of entire page to same color
    document.bgColor = colorRGB;  
    
}