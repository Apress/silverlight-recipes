﻿using System;
using System.Windows.Controls;
using System.Windows.Navigation;
using Expression.Blend.SampleData.SampleDataSource;

namespace Ch06_BrowserIntegration.Recipe6_10.Views
{
  public partial class ItemList : Page
  {
    public ItemList()
    {
      InitializeComponent();
    }

    // Executes when the user navigates to this page.
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
    }

    private void DataGrid_SelectionChanged(object sender, 
      SelectionChangedEventArgs e)
    {
      //test foo
      //this.NavigationService.Navigate(
      //  new Uri("foo",UriKind.Relative))

      // Navigate without parameters
      // this.NavigationService.Navigate( 
      //   new Uri(String.Format("/ItemDetails"), 
      //  UriKind.Relative));      

      //Navigate with parameters
      string lastName = ((Item)itemsDataGrid.SelectedItem).LastName;
      this.NavigationService.Navigate(
        new Uri(String.Format("/ItemDetails/{0}", lastName.ToString()),
        UriKind.Relative));
    }
  }
}