﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Ch06_BrowserIntegration.Recipe6_9
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void button1_Click(object sender, RoutedEventArgs e)
    {
      BrowserControl.Navigate(new Uri(textBox1.Text));      
    }

    private void BrowserControl_LoadCompleted(object sender, System.Windows.Navigation.NavigationEventArgs e)
    {
      ((WebBrowserBrush)rectangle1.Fill).SetSource(BrowserControl);
      ((WebBrowserBrush)ReflectionRect.Fill).SetSource(BrowserControl);
      
      AnimateRectangle.Begin();
    }
  }
}
